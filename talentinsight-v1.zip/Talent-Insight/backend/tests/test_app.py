"""
End-to-end tests of every feature. Run from the backend folder with:  pytest -v
AI is switched off in tests, so they check the rule-based fallbacks (same API, same shape).
"""
import io

from tests.conftest import HEADERS, login_as


# ---------- Health & security basics ----------

def test_health(client):
    r = client.get("/api/health")
    assert r.status_code == 200 and r.json()["database"] == "ok"


def test_security_headers(client):
    r = client.get("/api/health")
    assert r.headers["X-Content-Type-Options"] == "nosniff"
    assert "frame-ancestors 'none'" in r.headers["Content-Security-Policy"]
    assert r.headers["X-Request-ID"]


def test_frontend_is_served(client):
    r = client.get("/")
    assert r.status_code == 200 and "TalentInsight" in r.text


def test_requires_login(client):
    client.cookies.clear()
    assert client.get("/api/candidates").status_code == 401


def test_csrf_header_required(client):
    r = client.post("/api/auth/login", json={"email": "x@y.z", "password": "x"},
                    headers={"X-Requested-With": ""})
    assert r.status_code == 403


def test_wrong_password_and_rate_limit(client):
    from app.api.routes.auth import reset_rate_limits
    reset_rate_limits()
    for _ in range(5):
        assert client.post("/api/auth/login", json={"email": "admin@test.local", "password": "nope"}).status_code == 401
    assert client.post("/api/auth/login", json={"email": "admin@test.local", "password": "nope"}).status_code == 429
    reset_rate_limits()


# ---------- Auth & roles ----------

def test_login_me_logout(admin):
    me = admin.get("/api/auth/me").json()
    assert me["role"] == "admin"
    assert admin.post("/api/auth/logout").status_code == 200


def test_user_management_and_roles(admin):
    r = admin.post("/api/users", json={"email": "weak@test.local", "full_name": "Weak", "role": "recruiter",
                                       "password": "short"})
    assert r.status_code == 400
    r = admin.post("/api/users", json={"email": "hm@test.local", "full_name": "Hiring Manager",
                                       "role": "hiring_manager", "password": "Manager-Pass-1"})
    assert r.status_code == 201, r.text
    hm_id = r.json()["id"]
    r = admin.post("/api/users", json={"email": "rec@test.local", "full_name": "Recruiter One",
                                       "role": "recruiter", "password": "Recruit-Pass-1"})
    assert r.status_code == 201

    hm = login_as(admin, "hm@test.local", "Manager-Pass-1")
    assert hm.get("/api/candidates").status_code == 200          # can view
    assert hm.post("/api/jobs", json={"title": "X"}).status_code == 403  # can't create
    assert hm.get("/api/audit").status_code == 403

    login_as(admin, "admin@test.local", "AdminPass-12345")
    assert admin.patch(f"/api/users/{hm_id}", json={"is_active": False}).status_code == 200
    reset = admin.post(f"/api/users/{hm_id}/reset-password", json={"password": "Another-Pass-9"})
    assert reset.status_code == 200


def test_cannot_demote_self(admin):
    me = admin.get("/api/auth/me").json()
    assert admin.patch(f"/api/users/{me['id']}", json={"role": "recruiter"}).status_code == 400


# ---------- Candidates ----------

def test_demo_data_loaded(admin):
    data = admin.get("/api/candidates").json()
    assert data["total"] >= 5


def test_candidate_crud_search_notes(admin):
    r = admin.post("/api/candidates", json={"full_name": "Test Person", "email": "test.person@example.com",
                                            "skills": ["Python", "AWS"], "source": "Referral"})
    assert r.status_code == 201, r.text
    cid = r.json()["id"]
    assert admin.post("/api/candidates", json={"full_name": "Dup", "email": "test.person@example.com"}).status_code == 409
    assert admin.post("/api/candidates", json={"full_name": "Bad", "email": "not-an-email"}).status_code == 422

    found = admin.get("/api/candidates", params={"q": "Test Person"}).json()
    assert any(c["id"] == cid for c in found["items"])
    by_skill = admin.get("/api/candidates", params={"q": "AWS"}).json()
    assert any(c["id"] == cid for c in by_skill["items"])

    r = admin.patch(f"/api/candidates/{cid}", json={"current_title": "Engineer", "consent_status": "consented"})
    assert r.status_code == 200 and r.json()["consent_status"] == "consented"

    r = admin.post(f"/api/candidates/{cid}/notes", json={"body": "Great phone screen."})
    assert r.status_code == 201
    assert admin.get(f"/api/candidates/{cid}").json()["notes"][0]["body"] == "Great phone screen."

    assert admin.delete(f"/api/candidates/{cid}").status_code == 200
    assert admin.get(f"/api/candidates/{cid}").status_code == 404


def test_resume_upload_parse_and_download(admin):
    cv = (b"Neha Kapoor\nSenior Data Engineer\nneha.kapoor@example.com | +91 98765 43210\n"
          b"8 years of experience building pipelines with Python, Spark, Airflow and AWS.\n"
          b"Skills: SQL, Kafka, Docker")
    bad = b"not a pdf"
    r = admin.post("/api/candidates/upload", data={"source": "Naukri"},
                   files=[("files", ("neha.txt", io.BytesIO(cv), "text/plain")),
                          ("files", ("fake.pdf", io.BytesIO(bad), "application/pdf")),
                          ("files", ("old.doc", io.BytesIO(b"x"), "application/msword"))])
    assert r.status_code == 200, r.text
    results = r.json()["results"]
    assert results[0]["status"] == "created" and results[0]["method"] == "rules"
    assert results[1]["status"] == "rejected" and results[2]["status"] == "rejected"

    c = admin.get(f"/api/candidates/{results[0]['candidate_id']}").json()
    assert c["full_name"] == "Neha Kapoor"
    assert c["email"] == "neha.kapoor@example.com"
    assert c["years_experience"] == 8
    assert {"Python", "Spark", "Airflow", "AWS", "Kafka"} <= set(c["skills"])
    assert c["source"] == "Naukri"

    d = admin.get(f"/api/candidates/{c['id']}/resumes/{c['resumes'][0]['id']}")
    assert d.status_code == 200 and d.content == cv

    # Same email again -> updates the existing candidate instead of creating a duplicate
    r = admin.post("/api/candidates/upload", files=[("files", ("neha2.txt", io.BytesIO(cv), "text/plain"))])
    assert r.json()["results"][0]["status"] == "updated"


# ---------- Jobs, pipeline, matching, interviews ----------

def test_job_pipeline_match_interview(admin):
    r = admin.post("/api/jobs", json={"title": "Data Engineer", "location": "Pune",
                                      "must_have_skills": ["Python", "Spark", "SQL"],
                                      "nice_to_have_skills": ["Airflow", "Snowflake"]})
    assert r.status_code == 201, r.text
    jid = r.json()["id"]

    sugg = admin.get(f"/api/jobs/{jid}/suggestions").json()
    assert sugg["items"] and "Review" in sugg["notice"]
    top = sugg["items"][0]

    r = admin.post(f"/api/jobs/{jid}/applications", json={"candidate_id": top["candidate_id"]})
    assert r.status_code == 201, r.text
    app_id = r.json()["id"]
    assert admin.post(f"/api/jobs/{jid}/applications", json={"candidate_id": top["candidate_id"]}).status_code == 409

    m = admin.post(f"/api/applications/{app_id}/match").json()
    assert 0 <= m["match_score"] <= 100
    assert "not a hiring decision" in m["match_analysis"]["notice"]

    assert admin.patch(f"/api/applications/{app_id}", json={"stage": "bogus"}).status_code == 422
    assert admin.patch(f"/api/applications/{app_id}", json={"stage": "interview"}).json()["stage"] == "interview"

    i = admin.post(f"/api/applications/{app_id}/interviews",
                   json={"scheduled_at": "2030-01-15T10:00:00Z", "interviewer_name": "Sam"})
    assert i.status_code == 201, i.text
    iid = i.json()["id"]
    assert i.json()["kit"]["questions"]

    sc = admin.patch(f"/api/interviews/{iid}", json={"status": "completed",
                                                    "scorecard": {"ratings": {"Python": 4}, "recommendation": "yes"}})
    assert sc.status_code == 200 and sc.json()["scorecard"]["submitted_by"]
    assert any(x["id"] == iid for x in admin.get("/api/interviews").json())

    job = admin.get(f"/api/jobs/{jid}").json()
    assert job["stage_counts"]["interview"] == 1

    assert admin.patch(f"/api/applications/{app_id}", json={"stage": "hired"}).status_code == 200
    assert admin.patch(f"/api/jobs/{jid}", json={"status": "closed"}).json()["status"] == "closed"


# ---------- AI tools (fallback mode) ----------

def test_ai_status(admin):
    s = admin.get("/api/ai/status").json()
    assert s["enabled"] is False


def test_jd_generator(admin):
    r = admin.post("/api/ai/jd", json={"title": "QA Lead", "skills": ["Selenium", "Cypress"]})
    assert r.status_code == 200 and "QA Lead" in r.json()["text"] and r.json()["method"] == "rules"


def test_boolean_generator(admin):
    r = admin.post("/api/ai/boolean", json={"title": "Senior Java Developer", "must_have": ["Java", "Spring Boot"],
                                            "nice_to_have": ["AWS"], "exclude": ["intern"]}).json()
    assert '"Spring Boot"' in r["boolean"] and "NOT (intern)" in r["boolean"]


def test_email_generator(admin):
    for purpose in ("outreach", "interview_invite", "offer_intro", "rejection", "follow_up"):
        r = admin.post("/api/ai/email", json={"purpose": purpose, "candidate_name": "Asha", "role": "PM",
                                              "company": "Acme"}).json()
        assert r["subject"] and "Asha" in r["body"]


def test_interview_kit(admin):
    r = admin.post("/api/ai/interview-kit", json={"role": "DevOps Engineer", "skills": ["Kubernetes"]}).json()
    assert len(r["questions"]) >= 3 and r["scorecard_criteria"]


def test_chat_fallback(admin):
    r = admin.post("/api/ai/chat", json={"messages": [{"role": "user", "content": "How is my pipeline?"}]})
    assert r.status_code == 200 and "Open jobs" in r.json()["reply"]


# ---------- Analytics & audit ----------

def test_analytics(admin):
    a = admin.get("/api/analytics/summary").json()
    assert a["totals"]["candidates"] >= 5
    assert len(a["pipeline_by_stage"]) == 7 and len(a["applications_per_week"]) == 12
    assert a["funnel"][0]["count"] >= a["funnel"][-1]["count"]
    assert a["totals"]["hires_90d"] >= 1


def test_audit_log(admin):
    rows = admin.get("/api/audit").json()
    actions = {r["action"] for r in rows}
    assert {"login", "candidate_created", "resume_uploaded"} <= actions


def test_unknown_api_route_is_json_404(admin):
    r = admin.get("/api/does-not-exist")
    assert r.status_code == 404 and r.json()["detail"] == "Not found."
