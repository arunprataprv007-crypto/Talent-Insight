"""Unit tests for the rule-based engines (no web server needed)."""
from app.core.security import hash_password, password_problem, verify_password
from app.services import heuristics
from app.services.parsing import FileRejected, validate_file


def test_password_hashing():
    h = hash_password("Correct-Horse-1", iterations=1000)
    assert verify_password("Correct-Horse-1", h)
    assert not verify_password("wrong", h)
    assert not verify_password("x", "garbage")


def test_password_rules():
    assert password_problem("short")
    assert password_problem("alllowercase123")
    assert password_problem("NoNumbersHere")
    assert password_problem("Good-Pass-123") is None


def test_skill_extraction_boundaries():
    skills = heuristics.extract_skills("Worked with Java and JavaScript, Spring Boot, C# and Golang. Also Rust. Go to market.")
    assert {"Java", "JavaScript", "Spring Boot", "C#", "Golang", "Rust"} <= set(skills)
    assert "Spring" not in skills and "Go" not in skills


def test_redaction():
    t = heuristics.redact_contact_details("Call +44 7700 900123 or mail a.b@c.com linkedin.com/in/abc")
    assert "[phone]" in t and "[email]" in t and "[linkedin]" in t


def test_keyword_match():
    m = heuristics.keyword_match(["Python", "SQL"], "", ["Python", "SQL", "Spark"], ["AWS"])
    assert m["score"] == round(100 * 0.8 * 2 / 3)
    assert m["gaps"] == ["Spark"]


def test_file_validation():
    for name, data in [("a.doc", b"x"), ("a.exe", b"MZ"), ("a.pdf", b"nope"), ("a.txt", b"")]:
        try:
            validate_file(name, data, 1024)
            raise AssertionError(f"{name} should be rejected")
        except FileRejected:
            pass
    assert validate_file("cv.pdf", b"%PDF-1.7 ...", 1024) == "application/pdf"
