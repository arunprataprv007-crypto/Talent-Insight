"""
Test setup. Tests use a throwaway SQLite database file, so they never touch your real data
and don't need Docker running.
"""
import os
import sys
from pathlib import Path

TEST_DB = Path(__file__).parent / "test.db"
if TEST_DB.exists():
    TEST_DB.unlink()

os.environ.update({
    "DATABASE_URL": f"sqlite:///{TEST_DB}",
    "ENVIRONMENT": "test",
    "SECRET_KEY": "test-secret-key-that-is-long-enough-123456",
    "ADMIN_EMAIL": "admin@test.local",
    "ADMIN_PASSWORD": "AdminPass-12345",
    "SEED_DEMO_DATA": "true",
    "OPENAI_API_KEY": "",
    "PASSWORD_HASH_ITERATIONS": "1000",
})
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import pytest  # noqa: E402
from fastapi.testclient import TestClient  # noqa: E402

from app.api.routes.auth import reset_rate_limits  # noqa: E402
from app.main import app  # noqa: E402

HEADERS = {"X-Requested-With": "TalentInsight"}


@pytest.fixture(scope="session")
def client():
    with TestClient(app, headers=HEADERS) as c:  # "with" runs startup (creates tables + admin)
        yield c


@pytest.fixture()
def admin(client):
    reset_rate_limits()
    r = client.post("/api/auth/login", json={"email": "admin@test.local", "password": "AdminPass-12345"})
    assert r.status_code == 200, r.text
    return client


def login_as(client, email, password):
    reset_rate_limits()
    client.cookies.clear()
    r = client.post("/api/auth/login", json={"email": email, "password": password})
    assert r.status_code == 200, r.text
    return client
