"""Creates tables on startup, the first admin account, and optional fictional demo data."""
import logging
from datetime import timedelta

from sqlalchemy import func, select

from app.core.config import settings
from app.core.security import hash_password
from app.db.models import Application, Base, Candidate, Job, StageEvent, User, utcnow
from app.db.session import SessionLocal, engine

logger = logging.getLogger(__name__)


def init_db() -> None:
    Base.metadata.create_all(engine)
    with SessionLocal() as db:
        if db.scalar(select(func.count(User.id))) == 0:
            if settings.admin_password:
                admin = User(
                    email=settings.admin_email.strip().lower(),
                    full_name=settings.admin_name,
                    role="admin",
                    password_hash=hash_password(settings.admin_password, settings.password_hash_iterations),
                )
                db.add(admin)
                db.commit()
                logger.warning("Created first admin account for %s. Change the password after first login.", admin.email)
                if settings.seed_demo_data:
                    seed_demo(db, admin)
            else:
                logger.warning("No users exist. Set ADMIN_EMAIL and ADMIN_PASSWORD, then restart.")


def seed_demo(db, admin: User) -> None:
    """Fictional sample data so you can try every feature without real candidate data."""
    jobs = [
        Job(title="Senior Python Developer", department="Engineering", location="Hyderabad (Hybrid)",
            employment_type="Full-time", salary_range="30-40 LPA",
            description="Build and scale backend services for our recruitment platform.",
            must_have_skills=["Python", "FastAPI", "PostgreSQL", "REST APIs"],
            nice_to_have_skills=["Docker", "AWS", "Kubernetes"], created_by=admin.id),
        Job(title="Talent Acquisition Manager", department="People", location="Bengaluru (Onsite)",
            employment_type="Full-time", salary_range="25-35 LPA",
            description="Lead a team of recruiters hiring for technology and operations roles.",
            must_have_skills=["Stakeholder Management", "Sourcing", "Team Leadership"],
            nice_to_have_skills=["LinkedIn Recruiter", "Workday", "Employer Branding"], created_by=admin.id),
    ]
    db.add_all(jobs)
    people = [
        ("Asha Verma (Sample)", "Backend Engineer", ["Python", "FastAPI", "PostgreSQL", "Docker", "REST APIs"], 6, "LinkedIn"),
        ("Rohan Mehta (Sample)", "Software Engineer", ["Java", "Spring Boot", "MySQL", "AWS"], 4, "Referral"),
        ("Priya Nair (Sample)", "Python Developer", ["Python", "Django", "PostgreSQL", "Kubernetes"], 5, "Naukri"),
        ("Karan Shah (Sample)", "Senior Recruiter", ["Sourcing", "Stakeholder Management", "LinkedIn Recruiter"], 9, "LinkedIn"),
        ("Meera Iyer (Sample)", "TA Lead", ["Team Leadership", "Sourcing", "Workday", "Employer Branding"], 11, "Careers Page"),
    ]
    cands = []
    for i, (name, title, skills, yrs, src) in enumerate(people, start=1):
        c = Candidate(full_name=name, email=f"sample{i}@example.com", current_title=title,
                      skills=skills, years_experience=yrs, source=src, location="India",
                      summary=f"Fictional sample profile: {title} with {yrs} years of experience.",
                      owner_id=admin.id, parse_method="seed")
        cands.append(c)
    db.add_all(cands)
    db.flush()
    plan = [(0, 0, "interview"), (1, 0, "screening"), (2, 0, "shortlisted"), (3, 1, "offer"), (4, 1, "hired")]
    now = utcnow()
    for ci, ji, stage in plan:
        app = Application(candidate_id=cands[ci].id, job_id=jobs[ji].id, stage=stage,
                          created_at=now - timedelta(days=20 + ci), stage_changed_at=now - timedelta(days=ci))
        if stage == "hired":
            app.hired_at = now - timedelta(days=2)
        db.add(app)
        db.flush()
        db.add(StageEvent(application_id=app.id, from_stage=None, to_stage="sourced", changed_by=admin.id,
                          created_at=app.created_at))
        if stage != "sourced":
            db.add(StageEvent(application_id=app.id, from_stage="sourced", to_stage=stage, changed_by=admin.id))
    db.commit()
    logger.info("Loaded fictional demo data.")
