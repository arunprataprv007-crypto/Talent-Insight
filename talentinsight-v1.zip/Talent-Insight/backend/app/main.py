"""
Backend entry point.

Starts the API, creates tables, adds security protections, and serves the web interface
(the HTML/JS in /frontend) from the same address, so there's only one thing to deploy.
"""
import logging
import time
import uuid
from contextlib import asynccontextmanager
from pathlib import Path

from fastapi import FastAPI, Request
from fastapi.responses import JSONResponse
from fastapi.staticfiles import StaticFiles

from app.api.routes import ai_tools, analytics, applications, audit_log, auth, candidates, health, jobs, users
from app.core.config import settings
from app.core.logging import request_id_ctx, setup_logging
from app.db.init_db import init_db

setup_logging(settings.log_level)
logger = logging.getLogger("app")

UNSAFE_METHODS = {"POST", "PUT", "PATCH", "DELETE"}
CSRF_HEADER, CSRF_VALUE = "x-requested-with", "TalentInsight"

CSP = ("default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline'; img-src 'self' data:; "
       "connect-src 'self'; font-src 'self'; frame-ancestors 'none'; base-uri 'self'; form-action 'self'")


@asynccontextmanager
async def lifespan(_: FastAPI):
    settings.validate_for_production()
    init_db()
    logger.info("%s started (%s). AI %s.", settings.app_name, settings.environment,
                "enabled" if settings.openai_api_key else "not configured, using rule-based fallbacks")
    yield


app = FastAPI(title=f"{settings.app_name} API", version="1.0.0", lifespan=lifespan,
              docs_url=None if settings.is_production else "/docs", redoc_url=None,
              openapi_url=None if settings.is_production else "/openapi.json")


@app.middleware("http")
async def request_context(request: Request, call_next):
    request_id = request.headers.get("X-Request-ID", "")[:40] or uuid.uuid4().hex[:12]
    token = request_id_ctx.set(request_id)
    start = time.perf_counter()
    path = request.url.path
    try:
        # CSRF protection: browsers can't add custom headers to cross-site form posts.
        if path.startswith("/api/") and request.method in UNSAFE_METHODS \
                and request.headers.get(CSRF_HEADER) != CSRF_VALUE:
            response = JSONResponse(status_code=403, content={"detail": "Request blocked (missing security header)."})
        else:
            response = await call_next(request)
    except Exception:
        logger.exception("Unhandled error on %s %s", request.method, path)
        response = JSONResponse(status_code=500,
                                content={"detail": "Something went wrong on our side.", "request_id": request_id})

    response.headers["X-Request-ID"] = request_id
    response.headers["X-Content-Type-Options"] = "nosniff"
    response.headers["X-Frame-Options"] = "DENY"
    response.headers["Referrer-Policy"] = "strict-origin-when-cross-origin"
    response.headers["Permissions-Policy"] = "camera=(), microphone=(), geolocation=()"
    if not path.startswith(("/docs", "/openapi.json")):
        response.headers["Content-Security-Policy"] = CSP
    if settings.is_production:
        response.headers["Strict-Transport-Security"] = "max-age=31536000; includeSubDomains"
    if path.startswith("/api/"):
        response.headers["Cache-Control"] = "no-store"

    if path != "/api/health":
        logger.info("%s %s -> %s (%.0f ms)", request.method, path, response.status_code,
                    (time.perf_counter() - start) * 1000)
    request_id_ctx.reset(token)
    return response


for r in (health.router, auth.router, users.router, candidates.router, jobs.router, applications.router,
          ai_tools.router, analytics.router, audit_log.router):
    app.include_router(r, prefix="/api")


@app.api_route("/api/{path:path}", methods=["GET", "POST", "PUT", "PATCH", "DELETE"], include_in_schema=False)
def api_not_found(path: str):
    return JSONResponse(status_code=404, content={"detail": "Not found."})


frontend = Path(settings.frontend_dir)
if frontend.is_dir():
    app.mount("/", StaticFiles(directory=frontend, html=True), name="frontend")
else:
    logger.warning("Frontend folder not found at %s; only the API will be served.", frontend)
