"""Shared fixed values used across the app."""

ROLES = ("admin", "recruiter", "hiring_manager")
STAFF_ROLES = ("admin", "recruiter")          # can create/edit/upload and use AI tools

STAGES = ("sourced", "screening", "shortlisted", "interview", "offer", "hired", "rejected")
JOB_STATUSES = ("open", "on_hold", "closed")
CONSENT_STATUSES = ("not_recorded", "consented", "withdrawn")
INTERVIEW_STATUSES = ("scheduled", "completed", "cancelled")

HUMAN_REVIEW_NOTICE = (
    "AI suggestion for recruiter review. It is not a hiring decision. "
    "Check the evidence against the CV before acting."
)
