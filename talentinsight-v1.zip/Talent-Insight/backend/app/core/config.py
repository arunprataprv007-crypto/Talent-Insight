"""App settings, read from environment variables / the .env file."""
from functools import lru_cache
from pathlib import Path

from pydantic_settings import BaseSettings, SettingsConfigDict

BACKEND_DIR = Path(__file__).resolve().parents[2]
DEFAULT_FRONTEND_DIR = BACKEND_DIR.parent / "frontend"

_INSECURE_SECRETS = {"", "change-me", "dev-secret-change-me"}


class Settings(BaseSettings):
    app_name: str = "TalentInsight"
    environment: str = "development"
    log_level: str = "INFO"

    database_url: str = (
        "postgresql+psycopg://talentinsight:localdevpassword@localhost:5432/talentinsight"
    )

    secret_key: str = "dev-secret-change-me"
    access_token_minutes: int = 480
    password_hash_iterations: int = 600_000

    admin_email: str = "admin@example.com"
    admin_password: str = ""
    admin_name: str = "Administrator"
    seed_demo_data: bool = False

    openai_api_key: str = ""
    openai_model: str = "gpt-4o-mini"
    openai_base_url: str = ""
    ai_monthly_token_budget: int = 2_000_000

    max_upload_mb: int = 5
    frontend_dir: str = str(DEFAULT_FRONTEND_DIR)

    model_config = SettingsConfigDict(env_file=".env", extra="ignore")

    @property
    def is_production(self) -> bool:
        return self.environment.lower() == "production"

    @property
    def cookie_secure(self) -> bool:
        return self.is_production

    def validate_for_production(self) -> None:
        if not self.is_production:
            return
        if (self.secret_key in _INSECURE_SECRETS or "change-me" in self.secret_key.lower()
                or len(self.secret_key) < 32):
            raise RuntimeError(
                "SECRET_KEY must be set to a long random value (32+ chars) in production."
            )
        if self.admin_password and "changeme" in self.admin_password.lower().replace("-", ""):
            raise RuntimeError("ADMIN_PASSWORD is still the example value. Choose a real password.")


@lru_cache
def get_settings() -> Settings:
    return Settings()


settings = get_settings()
