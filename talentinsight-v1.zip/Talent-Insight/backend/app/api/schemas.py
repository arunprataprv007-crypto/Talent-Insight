"""Shapes of data the API accepts. Anything that doesn't fit is rejected with a clear error."""
import re
from datetime import datetime

from pydantic import BaseModel, Field, field_validator

from app.core.constants import CONSENT_STATUSES, INTERVIEW_STATUSES, JOB_STATUSES, ROLES, STAGES

_EMAIL = re.compile(r"^[^@\s]+@[^@\s]+\.[^@\s]+$")


def _check_email(v: str | None) -> str | None:
    if v is None or v == "":
        return None
    v = v.strip().lower()
    if not _EMAIL.match(v):
        raise ValueError("Enter a valid email address.")
    return v


def _clean_list(v):
    if v is None:
        return []
    return list(dict.fromkeys(str(x).strip()[:120] for x in v if str(x).strip()))[:60]


class LoginIn(BaseModel):
    email: str = Field(max_length=255)
    password: str = Field(max_length=200)


class ChangePasswordIn(BaseModel):
    current_password: str = Field(max_length=200)
    new_password: str = Field(max_length=200)


class UserCreate(BaseModel):
    email: str = Field(max_length=255)
    full_name: str = Field(min_length=1, max_length=200)
    role: str
    password: str = Field(max_length=200)

    v_e = field_validator("email")(_check_email)

    @field_validator("role")
    @classmethod
    def v_role(cls, v):
        if v not in ROLES:
            raise ValueError(f"Role must be one of {', '.join(ROLES)}.")
        return v


class UserUpdate(BaseModel):
    full_name: str | None = Field(default=None, max_length=200)
    role: str | None = None
    is_active: bool | None = None

    @field_validator("role")
    @classmethod
    def v_role(cls, v):
        if v is not None and v not in ROLES:
            raise ValueError(f"Role must be one of {', '.join(ROLES)}.")
        return v


class PasswordReset(BaseModel):
    password: str = Field(max_length=200)


class CandidateIn(BaseModel):
    full_name: str = Field(min_length=1, max_length=200)
    email: str | None = Field(default=None, max_length=255)
    phone: str | None = Field(default=None, max_length=50)
    location: str | None = Field(default=None, max_length=200)
    current_title: str | None = Field(default=None, max_length=200)
    current_company: str | None = Field(default=None, max_length=200)
    years_experience: float | None = Field(default=None, ge=0, le=60)
    linkedin_url: str | None = Field(default=None, max_length=300)
    summary: str | None = Field(default=None, max_length=5000)
    skills: list[str] = []
    tags: list[str] = []
    source: str = Field(default="Manual", max_length=100)
    consent_status: str = "not_recorded"

    v_e = field_validator("email")(_check_email)
    v_s = field_validator("skills", "tags", mode="before")(_clean_list)

    @field_validator("consent_status")
    @classmethod
    def v_consent(cls, v):
        if v not in CONSENT_STATUSES:
            raise ValueError("Invalid consent status.")
        return v


class CandidateUpdate(CandidateIn):
    full_name: str | None = Field(default=None, max_length=200)
    source: str | None = Field(default=None, max_length=100)
    consent_status: str | None = None

    @field_validator("consent_status")
    @classmethod
    def v_consent(cls, v):
        if v is not None and v not in CONSENT_STATUSES:
            raise ValueError("Invalid consent status.")
        return v


class NoteIn(BaseModel):
    body: str = Field(min_length=1, max_length=5000)


class JobIn(BaseModel):
    title: str = Field(min_length=1, max_length=200)
    department: str | None = Field(default=None, max_length=120)
    location: str | None = Field(default=None, max_length=200)
    employment_type: str | None = Field(default=None, max_length=60)
    salary_range: str | None = Field(default=None, max_length=120)
    description: str = Field(default="", max_length=20000)
    must_have_skills: list[str] = []
    nice_to_have_skills: list[str] = []
    boolean_string: str | None = Field(default=None, max_length=5000)
    status: str = "open"
    hiring_manager_id: int | None = None

    v_s = field_validator("must_have_skills", "nice_to_have_skills", mode="before")(_clean_list)

    @field_validator("status")
    @classmethod
    def v_status(cls, v):
        if v not in JOB_STATUSES:
            raise ValueError(f"Status must be one of {', '.join(JOB_STATUSES)}.")
        return v


class JobUpdate(JobIn):
    title: str | None = Field(default=None, max_length=200)
    status: str | None = None

    @field_validator("status")
    @classmethod
    def v_status(cls, v):
        if v is not None and v not in JOB_STATUSES:
            raise ValueError(f"Status must be one of {', '.join(JOB_STATUSES)}.")
        return v


class ApplicationIn(BaseModel):
    candidate_id: int


class StageIn(BaseModel):
    stage: str

    @field_validator("stage")
    @classmethod
    def v_stage(cls, v):
        if v not in STAGES:
            raise ValueError(f"Stage must be one of {', '.join(STAGES)}.")
        return v


class InterviewIn(BaseModel):
    scheduled_at: datetime | None = None
    interviewer_name: str | None = Field(default=None, max_length=200)
    mode: str = Field(default="video", max_length=30)
    focus: str = Field(default="", max_length=1000)


class InterviewUpdate(BaseModel):
    scheduled_at: datetime | None = None
    interviewer_name: str | None = Field(default=None, max_length=200)
    status: str | None = None
    scorecard: dict | None = None

    @field_validator("status")
    @classmethod
    def v_status(cls, v):
        if v is not None and v not in INTERVIEW_STATUSES:
            raise ValueError("Invalid interview status.")
        return v


class JDIn(BaseModel):
    title: str = Field(min_length=1, max_length=200)
    company: str = Field(default="", max_length=200)
    department: str = Field(default="", max_length=120)
    location: str = Field(default="", max_length=200)
    seniority: str = Field(default="", max_length=60)
    skills: list[str] = []
    notes: str = Field(default="", max_length=3000)
    tone: str = Field(default="professional", max_length=40)
    v_s = field_validator("skills", mode="before")(_clean_list)


class BooleanIn(BaseModel):
    title: str = Field(min_length=1, max_length=200)
    must_have: list[str] = []
    nice_to_have: list[str] = []
    exclude: list[str] = []
    location: str = Field(default="", max_length=200)
    platform: str = Field(default="LinkedIn", max_length=60)
    v_s = field_validator("must_have", "nice_to_have", "exclude", mode="before")(_clean_list)


class EmailIn(BaseModel):
    purpose: str = Field(default="outreach", max_length=40)
    candidate_name: str = Field(default="", max_length=200)
    role: str = Field(default="", max_length=200)
    company: str = Field(default="", max_length=200)
    recruiter_name: str = Field(default="", max_length=200)
    details: str = Field(default="", max_length=3000)
    tone: str = Field(default="warm and professional", max_length=60)


class InterviewKitIn(BaseModel):
    role: str = Field(min_length=1, max_length=200)
    skills: list[str] = []
    seniority: str = Field(default="", max_length=60)
    focus: str = Field(default="", max_length=1000)
    v_s = field_validator("skills", mode="before")(_clean_list)


class ChatMessage(BaseModel):
    role: str
    content: str = Field(max_length=4000)

    @field_validator("role")
    @classmethod
    def v_role(cls, v):
        if v not in ("user", "assistant"):
            raise ValueError("role must be user or assistant")
        return v


class ChatIn(BaseModel):
    messages: list[ChatMessage] = Field(min_length=1, max_length=30)
