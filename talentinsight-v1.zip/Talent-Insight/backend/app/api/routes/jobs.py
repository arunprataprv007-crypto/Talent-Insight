"""Job openings and their pipelines."""
from fastapi import APIRouter, Depends, HTTPException, Query, Request
from sqlalchemy import select
from sqlalchemy.exc import IntegrityError
from sqlalchemy.orm import Session, selectinload

from app.api.deps import client_ip, get_current_user, require_roles
from app.api.schemas import ApplicationIn, JobIn, JobUpdate
from app.api.serializers import application_out, job_out
from app.core.constants import STAFF_ROLES
from app.db.models import Application, Candidate, Job, StageEvent, User
from app.db.session import get_db
from app.services import heuristics
from app.services.audit import audit

router = APIRouter(prefix="/jobs", tags=["jobs"])
staff = require_roles(*STAFF_ROLES)


def _get(db: Session, job_id: int) -> Job:
    j = db.get(Job, job_id)
    if not j:
        raise HTTPException(404, "Job not found.")
    return j


def _check_manager(db: Session, manager_id: int | None) -> None:
    if manager_id is not None and not db.get(User, manager_id):
        raise HTTPException(400, "Hiring manager not found.")


@router.get("")
def list_jobs(status: str = "", _: User = Depends(get_current_user), db: Session = Depends(get_db)) -> list[dict]:
    stmt = select(Job).options(selectinload(Job.applications)).order_by(Job.created_at.desc(), Job.id.desc())
    if status:
        stmt = stmt.where(Job.status == status)
    return [job_out(j) for j in db.scalars(stmt)]


@router.post("", status_code=201)
def create_job(body: JobIn, request: Request, user: User = Depends(staff), db: Session = Depends(get_db)) -> dict:
    _check_manager(db, body.hiring_manager_id)
    j = Job(**body.model_dump(), created_by=user.id)
    db.add(j)
    db.flush()
    audit(db, user, "job_created", "job", j.id, {"title": j.title}, client_ip(request))
    db.commit()
    return job_out(j)


@router.get("/{job_id}")
def get_job(job_id: int, _: User = Depends(get_current_user), db: Session = Depends(get_db)) -> dict:
    return job_out(_get(db, job_id), with_pipeline=True)


@router.patch("/{job_id}")
def update_job(job_id: int, body: JobUpdate, request: Request, user: User = Depends(staff),
               db: Session = Depends(get_db)) -> dict:
    j = _get(db, job_id)
    changes = body.model_dump(exclude_unset=True)
    if "title" in changes and not changes["title"]:
        changes.pop("title")
    if "status" in changes and changes["status"] is None:
        changes.pop("status")
    _check_manager(db, changes.get("hiring_manager_id"))
    for k, v in changes.items():
        setattr(j, k, v)
    audit(db, user, "job_updated", "job", j.id, {"fields": sorted(changes)}, client_ip(request))
    db.commit()
    return job_out(j, with_pipeline=True)


@router.delete("/{job_id}")
def delete_job(job_id: int, request: Request, user: User = Depends(require_roles("admin")),
               db: Session = Depends(get_db)) -> dict:
    j = _get(db, job_id)
    audit(db, user, "job_deleted", "job", j.id, {"title": j.title}, client_ip(request))
    db.delete(j)
    db.commit()
    return {"ok": True}


@router.post("/{job_id}/applications", status_code=201)
def add_to_pipeline(job_id: int, body: ApplicationIn, request: Request, user: User = Depends(staff),
                    db: Session = Depends(get_db)) -> dict:
    j = _get(db, job_id)
    if not db.get(Candidate, body.candidate_id):
        raise HTTPException(404, "Candidate not found.")
    a = Application(candidate_id=body.candidate_id, job_id=j.id, stage="sourced")
    db.add(a)
    try:
        db.flush()
    except IntegrityError:
        db.rollback()
        raise HTTPException(409, "This candidate is already in this job's pipeline.")
    db.add(StageEvent(application_id=a.id, from_stage=None, to_stage="sourced", changed_by=user.id))
    audit(db, user, "added_to_pipeline", "application", a.id, {"job_id": j.id, "candidate_id": body.candidate_id},
          client_ip(request))
    db.commit()
    db.refresh(a)
    return application_out(a, include_candidate=True)


@router.get("/{job_id}/suggestions")
def suggest_candidates(job_id: int, limit: int = Query(15, ge=1, le=50), _: User = Depends(staff),
                       db: Session = Depends(get_db)) -> dict:
    """Quick keyword pre-screen across the whole candidate database (no AI cost).
    It only suggests people to look at; a recruiter decides who to add."""
    j = _get(db, job_id)
    in_pipeline = {a.candidate_id for a in j.applications}
    scored = []
    for c in db.scalars(select(Candidate)):
        if c.id in in_pipeline:
            continue
        text = " ".join(filter(None, [c.current_title, c.summary]))
        m = heuristics.keyword_match(c.skills or [], text, j.must_have_skills or [], j.nice_to_have_skills or [])
        if m["score"] > 0:
            scored.append({"candidate_id": c.id, "full_name": c.full_name, "current_title": c.current_title,
                           "score": m["score"], "strengths": m["strengths"], "gaps": m["gaps"]})
    scored.sort(key=lambda x: x["score"], reverse=True)
    return {"items": scored[:limit],
            "notice": "Keyword pre-screen only. Review each profile before adding to the pipeline."}
