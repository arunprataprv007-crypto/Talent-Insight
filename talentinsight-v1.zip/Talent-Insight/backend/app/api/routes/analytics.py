"""Recruitment analytics and the anonymised snapshot the chat assistant uses."""
from collections import Counter
from datetime import datetime, timedelta, timezone

from fastapi import APIRouter, Depends
from sqlalchemy import func, select
from sqlalchemy.orm import Session, selectinload

from app.api.deps import get_current_user
from app.core.constants import STAGES
from app.db.models import Application, Candidate, Interview, Job, User
from app.db.session import get_db
from app.services.ai_client import tokens_used_this_month

router = APIRouter(prefix="/analytics", tags=["analytics"])


def _aware(d: datetime | None) -> datetime | None:
    if d is None:
        return None
    return d if d.tzinfo else d.replace(tzinfo=timezone.utc)


def pipeline_snapshot(db: Session) -> dict:
    """Aggregate numbers only: no names, emails or phone numbers."""
    by_stage = dict(db.execute(select(Application.stage, func.count()).group_by(Application.stage)).all())
    jobs = db.scalars(select(Job).options(selectinload(Job.applications)).where(Job.status == "open")).all()
    return {
        "total_candidates": db.scalar(select(func.count(Candidate.id))) or 0,
        "open_jobs": len(jobs),
        "pipeline_by_stage": {s: by_stage.get(s, 0) for s in STAGES},
        "jobs": [{"title": j.title, "location": j.location, "must_have_skills": j.must_have_skills,
                  "pipeline": dict(Counter(a.stage for a in j.applications))} for j in jobs[:25]],
        "top_skills": [s for s, _ in Counter(
            s for skills in db.scalars(select(Candidate.skills)) for s in (skills or [])).most_common(15)],
    }


@router.get("/summary")
def summary(_: User = Depends(get_current_user), db: Session = Depends(get_db)) -> dict:
    now = datetime.now(timezone.utc)
    apps = db.scalars(select(Application).options(
        selectinload(Application.events), selectinload(Application.candidate))).all()
    by_stage = Counter(a.stage for a in apps)

    # Funnel: how many applications ever reached each stage (using stage history, falling back to current stage)
    order = [s for s in STAGES if s != "rejected"]
    reached = Counter()
    for a in apps:
        stages_seen = {e.to_stage for e in a.events} | {a.stage}
        top = max((order.index(s) for s in stages_seen if s in order), default=0)
        for s in order[: top + 1]:
            reached[s] += 1

    hires = [a for a in apps if a.stage == "hired" and a.hired_at]
    days_to_hire = [(_aware(a.hired_at) - _aware(a.created_at)).days for a in hires]
    recent_hires = [a for a in hires if _aware(a.hired_at) >= now - timedelta(days=90)]

    weeks = []
    for w in range(11, -1, -1):
        start = (now - timedelta(days=now.weekday(), weeks=w)).replace(hour=0, minute=0, second=0, microsecond=0)
        end = start + timedelta(weeks=1)
        weeks.append({"week_start": start.date().isoformat(),
                      "count": sum(1 for a in apps if start <= _aware(a.created_at) < end)})

    sources = Counter(db.scalars(select(Candidate.source)))
    hired_by_source = Counter(a.candidate.source for a in hires)
    scores = [a.match_score for a in apps if a.match_score is not None]

    jobs = db.scalars(select(Job).options(selectinload(Job.applications))).all()
    upcoming = db.scalar(select(func.count(Interview.id)).where(
        Interview.status == "scheduled", Interview.scheduled_at >= now)) or 0

    return {
        "totals": {
            "candidates": db.scalar(select(func.count(Candidate.id))) or 0,
            "open_jobs": sum(1 for j in jobs if j.status == "open"),
            "active_applications": sum(v for k, v in by_stage.items() if k not in ("hired", "rejected")),
            "hires_90d": len(recent_hires),
            "upcoming_interviews": upcoming,
            "avg_days_to_hire": round(sum(days_to_hire) / len(days_to_hire), 1) if days_to_hire else None,
            "avg_match_score": round(sum(scores) / len(scores)) if scores else None,
        },
        "pipeline_by_stage": [{"stage": s, "count": by_stage.get(s, 0)} for s in STAGES],
        "funnel": [{"stage": s, "count": reached.get(s, 0)} for s in order],
        "applications_per_week": weeks,
        "sources": [{"source": s, "candidates": n, "hires": hired_by_source.get(s, 0)}
                    for s, n in sources.most_common()],
        "jobs": [{"id": j.id, "title": j.title, "status": j.status, "total": len(j.applications),
                  "hired": sum(1 for a in j.applications if a.stage == "hired"),
                  "age_days": (now - _aware(j.created_at)).days} for j in jobs],
        "ai_tokens_this_month": tokens_used_this_month(db),
    }
