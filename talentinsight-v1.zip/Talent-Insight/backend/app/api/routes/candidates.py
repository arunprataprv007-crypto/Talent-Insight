"""Candidate CRM: list, search, create, edit, delete, CV upload & parsing, notes."""
import logging
import re

from fastapi import APIRouter, Depends, File, Form, HTTPException, Query, Request, UploadFile
from fastapi.responses import Response
from sqlalchemy import String, cast, func, or_, select
from sqlalchemy.orm import Session, selectinload, undefer

from app.api.deps import client_ip, get_current_user, require_roles
from app.api.schemas import CandidateIn, CandidateUpdate, NoteIn
from app.api.serializers import candidate_detail, candidate_summary, note_out
from app.core.config import settings
from app.core.constants import STAFF_ROLES
from app.db.models import Application, Candidate, Note, ResumeFile, User
from app.db.session import get_db
from app.services import recruiting_ai
from app.services.audit import audit
from app.services.parsing import FileRejected, extract_text, validate_file

router = APIRouter(prefix="/candidates", tags=["candidates"])
logger = logging.getLogger(__name__)
staff = require_roles(*STAFF_ROLES)

MAX_FILES_PER_UPLOAD = 25


def _get(db: Session, candidate_id: int) -> Candidate:
    c = db.get(Candidate, candidate_id)
    if not c:
        raise HTTPException(404, "Candidate not found.")
    return c


@router.get("")
def list_candidates(q: str = Query("", max_length=200), stage: str = "", source: str = "",
                    limit: int = Query(50, ge=1, le=200), offset: int = Query(0, ge=0),
                    _: User = Depends(get_current_user), db: Session = Depends(get_db)) -> dict:
    stmt = select(Candidate).options(selectinload(Candidate.applications))
    if q.strip():
        terms = [t for t in re.split(r"\s+", q.strip()) if t][:6]
        for t in terms:
            like = f"%{t}%"
            stmt = stmt.where(or_(Candidate.full_name.ilike(like), Candidate.email.ilike(like),
                                  Candidate.current_title.ilike(like), Candidate.current_company.ilike(like),
                                  Candidate.location.ilike(like), cast(Candidate.skills, String).ilike(like),
                                  cast(Candidate.tags, String).ilike(like)))
    if source:
        stmt = stmt.where(Candidate.source == source)
    if stage:
        stmt = stmt.where(Candidate.id.in_(select(Application.candidate_id).where(Application.stage == stage)))
    total = db.scalar(select(func.count()).select_from(stmt.order_by(None).subquery()))
    rows = db.scalars(stmt.order_by(Candidate.created_at.desc(), Candidate.id.desc()).limit(limit).offset(offset))
    return {"total": total, "items": [candidate_summary(c) for c in rows]}


@router.post("", status_code=201)
def create_candidate(body: CandidateIn, request: Request, user: User = Depends(staff),
                     db: Session = Depends(get_db)) -> dict:
    if body.email and db.scalar(select(Candidate).where(Candidate.email == body.email)):
        raise HTTPException(409, "A candidate with this email already exists.")
    c = Candidate(**body.model_dump(), owner_id=user.id, parse_method="manual")
    db.add(c)
    db.flush()
    audit(db, user, "candidate_created", "candidate", c.id, None, client_ip(request))
    db.commit()
    return candidate_detail(c)


@router.post("/upload")
def upload_resumes(request: Request, files: list[UploadFile] = File(...), source: str = Form("Upload"),
                   user: User = Depends(staff), db: Session = Depends(get_db)) -> dict:
    if len(files) > MAX_FILES_PER_UPLOAD:
        raise HTTPException(400, f"Upload up to {MAX_FILES_PER_UPLOAD} files at a time.")
    max_bytes = settings.max_upload_mb * 1024 * 1024
    results = []
    for f in files:
        name = (f.filename or "resume").replace("/", "_").replace("\\", "_")[:200]
        try:
            data = f.file.read(max_bytes + 1)
            content_type = validate_file(name, data, max_bytes)
            text = extract_text(name, data)
        except FileRejected as exc:
            results.append({"filename": name, "status": "rejected", "message": str(exc)})
            continue

        parsed, method = recruiting_ai.parse_resume(db, text, user.id)
        existing = None
        if parsed.get("email"):
            existing = db.scalar(select(Candidate).where(Candidate.email == parsed["email"].lower()))
        if existing:
            c, status = existing, "updated"
            # Add any newly found skills without overwriting what recruiters entered.
            c.skills = list(dict.fromkeys((c.skills or []) + (parsed.get("skills") or [])))
        else:
            c = Candidate(
                full_name=parsed.get("full_name") or name.rsplit(".", 1)[0][:200],
                email=(parsed.get("email") or None) and parsed["email"].lower(),
                phone=parsed.get("phone"), location=parsed.get("location"),
                current_title=parsed.get("current_title"), current_company=parsed.get("current_company"),
                years_experience=parsed.get("years_experience"), linkedin_url=parsed.get("linkedin_url"),
                summary=parsed.get("summary"), skills=parsed.get("skills") or [],
                education=parsed.get("education") or [], experience=parsed.get("experience") or [],
                source=source[:100] or "Upload", owner_id=user.id, parse_method=method,
            )
            db.add(c)
            db.flush()
            status = "created"
        db.add(ResumeFile(candidate_id=c.id, filename=name, content_type=content_type, size_bytes=len(data),
                          data=data, text=text, uploaded_by=user.id))
        audit(db, user, "resume_uploaded", "candidate", c.id, {"filename": name, "method": method},
              client_ip(request))
        db.commit()
        results.append({"filename": name, "status": status, "candidate_id": c.id,
                        "full_name": c.full_name, "method": method})
    return {"results": results}


@router.get("/{candidate_id}")
def get_candidate(candidate_id: int, _: User = Depends(get_current_user), db: Session = Depends(get_db)) -> dict:
    return candidate_detail(_get(db, candidate_id))


@router.patch("/{candidate_id}")
def update_candidate(candidate_id: int, body: CandidateUpdate, request: Request, user: User = Depends(staff),
                     db: Session = Depends(get_db)) -> dict:
    c = _get(db, candidate_id)
    changes = body.model_dump(exclude_unset=True)
    if "full_name" in changes and not changes["full_name"]:
        changes.pop("full_name")
    if changes.get("email") and changes["email"] != c.email and db.scalar(
            select(Candidate).where(Candidate.email == changes["email"])):
        raise HTTPException(409, "Another candidate already uses this email.")
    for k, v in changes.items():
        setattr(c, k, v)
    audit(db, user, "candidate_updated", "candidate", c.id, {"fields": sorted(changes)}, client_ip(request))
    db.commit()
    return candidate_detail(c)


@router.delete("/{candidate_id}")
def delete_candidate(candidate_id: int, request: Request, user: User = Depends(require_roles("admin")),
                     db: Session = Depends(get_db)) -> dict:
    """Permanently erase a candidate and their files (e.g. a data-erasure request)."""
    c = _get(db, candidate_id)
    audit(db, user, "candidate_deleted", "candidate", c.id, None, client_ip(request))
    db.delete(c)
    db.commit()
    return {"ok": True}


@router.get("/{candidate_id}/resumes/{file_id}")
def download_resume(candidate_id: int, file_id: int, request: Request, user: User = Depends(get_current_user),
                    db: Session = Depends(get_db)) -> Response:
    r = db.scalar(select(ResumeFile).options(undefer(ResumeFile.data))
                  .where(ResumeFile.id == file_id, ResumeFile.candidate_id == candidate_id))
    if not r:
        raise HTTPException(404, "File not found.")
    audit(db, user, "resume_downloaded", "candidate", candidate_id, {"file_id": file_id}, client_ip(request))
    db.commit()
    safe = re.sub(r"[^\w.\- ]", "_", r.filename)
    return Response(r.data, media_type=r.content_type,
                    headers={"Content-Disposition": f'attachment; filename="{safe}"'})


@router.post("/{candidate_id}/reparse")
def reparse(candidate_id: int, request: Request, user: User = Depends(staff), db: Session = Depends(get_db)) -> dict:
    c = _get(db, candidate_id)
    if not c.resumes:
        raise HTTPException(400, "This candidate has no CV to parse.")
    parsed, method = recruiting_ai.parse_resume(db, c.resumes[0].text, user.id)
    for field in ("phone", "location", "current_title", "current_company", "years_experience",
                  "linkedin_url", "summary", "education", "experience"):
        if parsed.get(field):
            setattr(c, field, parsed[field])
    c.skills = list(dict.fromkeys((c.skills or []) + (parsed.get("skills") or [])))
    c.parse_method = method
    audit(db, user, "resume_reparsed", "candidate", c.id, {"method": method}, client_ip(request))
    db.commit()
    return candidate_detail(c)


@router.post("/{candidate_id}/notes", status_code=201)
def add_note(candidate_id: int, body: NoteIn, user: User = Depends(get_current_user),
             db: Session = Depends(get_db)) -> dict:
    c = _get(db, candidate_id)
    n = Note(candidate_id=c.id, author_id=user.id, body=body.body.strip())
    db.add(n)
    db.commit()
    db.refresh(n)
    return note_out(n)
