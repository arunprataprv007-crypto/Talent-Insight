"""Standalone AI tools: JD, Boolean, email, interview kit, chat, and AI status."""
from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session

from app.api.deps import get_current_user, require_roles
from app.api.routes.analytics import pipeline_snapshot
from app.api.schemas import BooleanIn, ChatIn, EmailIn, InterviewKitIn, JDIn
from app.core.config import settings
from app.core.constants import STAFF_ROLES
from app.db.models import User
from app.db.session import get_db
from app.services import recruiting_ai
from app.services.ai_client import ai_enabled, tokens_used_this_month

router = APIRouter(prefix="/ai", tags=["ai"])
staff = require_roles(*STAFF_ROLES)


@router.get("/status")
def status(_: User = Depends(get_current_user), db: Session = Depends(get_db)) -> dict:
    return {"enabled": ai_enabled(), "model": settings.openai_model if ai_enabled() else None,
            "tokens_used_this_month": tokens_used_this_month(db),
            "monthly_budget": settings.ai_monthly_token_budget}


@router.post("/jd")
def jd(body: JDIn, user: User = Depends(staff), db: Session = Depends(get_db)) -> dict:
    return recruiting_ai.generate_jd(db, title=body.title, department=body.department, location=body.location,
                                     seniority=body.seniority, skills=body.skills, notes=body.notes,
                                     company=body.company, tone=body.tone, user_id=user.id)


@router.post("/boolean")
def boolean(body: BooleanIn, user: User = Depends(staff), db: Session = Depends(get_db)) -> dict:
    return recruiting_ai.generate_boolean(db, title=body.title, must_have=body.must_have,
                                          nice_to_have=body.nice_to_have, exclude=body.exclude,
                                          location=body.location, platform=body.platform, user_id=user.id)


@router.post("/email")
def email(body: EmailIn, user: User = Depends(staff), db: Session = Depends(get_db)) -> dict:
    return recruiting_ai.generate_email(db, purpose=body.purpose, candidate_name=body.candidate_name,
                                        role=body.role, company=body.company,
                                        recruiter_name=body.recruiter_name or user.full_name,
                                        details=body.details, tone=body.tone, user_id=user.id)


@router.post("/interview-kit")
def interview_kit(body: InterviewKitIn, user: User = Depends(get_current_user), db: Session = Depends(get_db)) -> dict:
    return recruiting_ai.generate_interview_kit(db, role=body.role, skills=body.skills, seniority=body.seniority,
                                                focus=body.focus, user_id=user.id)


@router.post("/chat")
def chat(body: ChatIn, user: User = Depends(get_current_user), db: Session = Depends(get_db)) -> dict:
    return recruiting_ai.chat(db, messages=[m.model_dump() for m in body.messages],
                              context=pipeline_snapshot(db), user_id=user.id)
