"""Sign in, sign out, who am I, change password."""
import threading
import time
from datetime import datetime, timezone

from fastapi import APIRouter, Depends, HTTPException, Request, Response
from sqlalchemy import select
from sqlalchemy.orm import Session

from app.api.deps import COOKIE_NAME, client_ip, get_current_user
from app.api.schemas import ChangePasswordIn, LoginIn
from app.api.serializers import user_out
from app.core.config import settings
from app.core.security import create_access_token, hash_password, password_problem, verify_password
from app.db.models import User
from app.db.session import get_db
from app.services.audit import audit

router = APIRouter(prefix="/auth", tags=["auth"])

# Simple brute-force protection: max 5 failed attempts per email+IP in 15 minutes.
_FAILS: dict[str, list[float]] = {}
_LOCK = threading.Lock()
WINDOW, MAX_FAILS = 15 * 60, 5


def _too_many(key: str) -> bool:
    now = time.time()
    with _LOCK:
        attempts = [t for t in _FAILS.get(key, []) if now - t < WINDOW]
        _FAILS[key] = attempts
        return len(attempts) >= MAX_FAILS


def _record_fail(key: str) -> None:
    with _LOCK:
        _FAILS.setdefault(key, []).append(time.time())


def reset_rate_limits() -> None:  # used by tests
    with _LOCK:
        _FAILS.clear()


@router.post("/login")
def login(body: LoginIn, request: Request, response: Response, db: Session = Depends(get_db)) -> dict:
    email = body.email.strip().lower()
    key = f"{email}|{client_ip(request)}"
    if _too_many(key):
        raise HTTPException(429, "Too many failed attempts. Wait 15 minutes and try again.")
    user = db.scalar(select(User).where(User.email == email))
    if not user or not user.is_active or not verify_password(body.password, user.password_hash):
        _record_fail(key)
        audit(db, None, "login_failed", "user", None, {"email": email}, client_ip(request))
        db.commit()
        raise HTTPException(401, "Email or password is incorrect.")

    token = create_access_token(user.id, user.role, settings.secret_key, settings.access_token_minutes)
    response.set_cookie(COOKIE_NAME, token, httponly=True, secure=settings.cookie_secure, samesite="lax",
                        max_age=settings.access_token_minutes * 60, path="/")
    user.last_login_at = datetime.now(timezone.utc)
    audit(db, user, "login", "user", user.id, None, client_ip(request))
    db.commit()
    return user_out(user)


@router.post("/logout")
def logout(response: Response) -> dict:
    response.delete_cookie(COOKIE_NAME, path="/")
    return {"ok": True}


@router.get("/me")
def me(user: User = Depends(get_current_user)) -> dict:
    return user_out(user)


@router.post("/change-password")
def change_password(body: ChangePasswordIn, request: Request, user: User = Depends(get_current_user),
                    db: Session = Depends(get_db)) -> dict:
    if not verify_password(body.current_password, user.password_hash):
        raise HTTPException(400, "Current password is incorrect.")
    problem = password_problem(body.new_password)
    if problem:
        raise HTTPException(400, problem)
    user.password_hash = hash_password(body.new_password, settings.password_hash_iterations)
    audit(db, user, "password_changed", "user", user.id, None, client_ip(request))
    db.commit()
    return {"ok": True}
