"""User management (admins only)."""
from fastapi import APIRouter, Depends, HTTPException, Request
from sqlalchemy import select
from sqlalchemy.orm import Session

from app.api.deps import client_ip, get_current_user, require_roles
from app.api.schemas import PasswordReset, UserCreate, UserUpdate
from app.api.serializers import user_out
from app.core.config import settings
from app.core.security import hash_password, password_problem
from app.db.models import User
from app.db.session import get_db
from app.services.audit import audit

router = APIRouter(prefix="/users", tags=["users"])
admin_only = require_roles("admin")


@router.get("")
def list_users(_: User = Depends(get_current_user), db: Session = Depends(get_db)) -> list[dict]:
    # Everyone can see the team list (needed to pick hiring managers); only admins can change it.
    return [user_out(u) for u in db.scalars(select(User).order_by(User.full_name))]


@router.post("", status_code=201)
def create_user(body: UserCreate, request: Request, admin: User = Depends(admin_only),
                db: Session = Depends(get_db)) -> dict:
    if db.scalar(select(User).where(User.email == body.email)):
        raise HTTPException(409, "A user with this email already exists.")
    problem = password_problem(body.password)
    if problem:
        raise HTTPException(400, problem)
    user = User(email=body.email, full_name=body.full_name, role=body.role,
                password_hash=hash_password(body.password, settings.password_hash_iterations))
    db.add(user)
    db.flush()
    audit(db, admin, "user_created", "user", user.id, {"role": user.role}, client_ip(request))
    db.commit()
    return user_out(user)


@router.patch("/{user_id}")
def update_user(user_id: int, body: UserUpdate, request: Request, admin: User = Depends(admin_only),
                db: Session = Depends(get_db)) -> dict:
    user = db.get(User, user_id)
    if not user:
        raise HTTPException(404, "User not found.")
    changes = body.model_dump(exclude_unset=True, exclude_none=True)
    if user.id == admin.id and (changes.get("is_active") is False or changes.get("role", "admin") != "admin"):
        raise HTTPException(400, "You can't remove your own admin access or deactivate yourself.")
    for k, v in changes.items():
        setattr(user, k, v)
    audit(db, admin, "user_updated", "user", user.id, changes, client_ip(request))
    db.commit()
    return user_out(user)


@router.post("/{user_id}/reset-password")
def reset_password(user_id: int, body: PasswordReset, request: Request, admin: User = Depends(admin_only),
                   db: Session = Depends(get_db)) -> dict:
    user = db.get(User, user_id)
    if not user:
        raise HTTPException(404, "User not found.")
    problem = password_problem(body.password)
    if problem:
        raise HTTPException(400, problem)
    user.password_hash = hash_password(body.password, settings.password_hash_iterations)
    audit(db, admin, "password_reset", "user", user.id, None, client_ip(request))
    db.commit()
    return {"ok": True}
