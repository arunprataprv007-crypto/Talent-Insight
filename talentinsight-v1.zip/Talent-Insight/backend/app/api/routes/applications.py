"""Pipeline actions: move stage, AI match, interviews and scorecards."""
from datetime import datetime, timezone

from fastapi import APIRouter, Depends, HTTPException, Request
from sqlalchemy import select
from sqlalchemy.orm import Session, selectinload

from app.api.deps import client_ip, get_current_user, require_roles
from app.api.schemas import InterviewIn, InterviewUpdate, StageIn
from app.api.serializers import application_out, interview_out
from app.core.constants import STAFF_ROLES
from app.db.models import Application, Interview, StageEvent, User
from app.db.session import get_db
from app.services import recruiting_ai
from app.services.audit import audit

router = APIRouter(tags=["pipeline"])
staff = require_roles(*STAFF_ROLES)


def _get(db: Session, app_id: int) -> Application:
    a = db.get(Application, app_id)
    if not a:
        raise HTTPException(404, "Pipeline entry not found.")
    return a


@router.patch("/applications/{app_id}")
def change_stage(app_id: int, body: StageIn, request: Request, user: User = Depends(staff),
                 db: Session = Depends(get_db)) -> dict:
    a = _get(db, app_id)
    if body.stage != a.stage:
        db.add(StageEvent(application_id=a.id, from_stage=a.stage, to_stage=body.stage, changed_by=user.id))
        old = a.stage
        a.stage = body.stage
        a.stage_changed_at = datetime.now(timezone.utc)
        a.hired_at = a.stage_changed_at if body.stage == "hired" else None
        audit(db, user, "stage_changed", "application", a.id, {"from": old, "to": body.stage}, client_ip(request))
        db.commit()
    return application_out(a, include_candidate=True, include_job=True)


@router.delete("/applications/{app_id}")
def remove_from_pipeline(app_id: int, request: Request, user: User = Depends(staff),
                         db: Session = Depends(get_db)) -> dict:
    a = _get(db, app_id)
    audit(db, user, "removed_from_pipeline", "application", a.id, None, client_ip(request))
    db.delete(a)
    db.commit()
    return {"ok": True}


@router.post("/applications/{app_id}/match")
def run_match(app_id: int, request: Request, user: User = Depends(staff), db: Session = Depends(get_db)) -> dict:
    a = _get(db, app_id)
    c, j = a.candidate, a.job
    profile = {"current_title": c.current_title, "years_experience": c.years_experience, "skills": c.skills,
               "education": c.education, "experience": c.experience, "summary": c.summary}
    resume_text = c.resumes[0].text if c.resumes else ""
    job = {"title": j.title, "description": j.description, "must_have_skills": j.must_have_skills,
           "nice_to_have_skills": j.nice_to_have_skills, "location": j.location}
    result = recruiting_ai.match_candidate(db, candidate_profile=profile, resume_text=resume_text, job=job,
                                           user_id=user.id)
    result["run_at"] = datetime.now(timezone.utc).isoformat()
    result["run_by"] = user.full_name
    a.match_score = result["score"]
    a.match_analysis = result
    audit(db, user, "match_run", "application", a.id, {"score": result["score"], "method": result["method"]},
          client_ip(request))
    db.commit()
    return application_out(a, include_candidate=True, include_job=True)


@router.post("/applications/{app_id}/interviews", status_code=201)
def schedule_interview(app_id: int, body: InterviewIn, request: Request, user: User = Depends(staff),
                       db: Session = Depends(get_db)) -> dict:
    a = _get(db, app_id)
    skills = list(dict.fromkeys((a.job.must_have_skills or []) + (a.job.nice_to_have_skills or [])))
    focus = body.focus or ", ".join((a.match_analysis or {}).get("interview_focus", [])[:4])
    kit = recruiting_ai.generate_interview_kit(db, role=a.job.title, skills=skills, seniority="", focus=focus,
                                               user_id=user.id)
    i = Interview(application_id=a.id, scheduled_at=body.scheduled_at, interviewer_name=body.interviewer_name,
                  mode=body.mode, kit=kit, created_by=user.id)
    db.add(i)
    db.flush()
    audit(db, user, "interview_scheduled", "interview", i.id, {"application_id": a.id}, client_ip(request))
    db.commit()
    return interview_out(i)


@router.get("/interviews")
def list_interviews(_: User = Depends(get_current_user), db: Session = Depends(get_db)) -> list[dict]:
    stmt = (select(Interview).options(selectinload(Interview.application))
            .order_by(Interview.scheduled_at.is_(None), Interview.scheduled_at, Interview.id.desc()).limit(200))
    out = []
    for i in db.scalars(stmt):
        d = interview_out(i)
        d["candidate"] = {"id": i.application.candidate.id, "full_name": i.application.candidate.full_name}
        d["job"] = {"id": i.application.job.id, "title": i.application.job.title}
        out.append(d)
    return out


@router.patch("/interviews/{interview_id}")
def update_interview(interview_id: int, body: InterviewUpdate, request: Request,
                     user: User = Depends(get_current_user), db: Session = Depends(get_db)) -> dict:
    """Interviewers (including hiring managers) record scorecards here."""
    i = db.get(Interview, interview_id)
    if not i:
        raise HTTPException(404, "Interview not found.")
    changes = body.model_dump(exclude_unset=True)
    if user.role not in STAFF_ROLES and set(changes) - {"scorecard", "status"}:
        raise HTTPException(403, "Hiring managers can only submit scorecards.")
    if "scorecard" in changes and changes["scorecard"] is not None:
        changes["scorecard"] = {**changes["scorecard"], "submitted_by": user.full_name,
                                "submitted_at": datetime.now(timezone.utc).isoformat()}
    for k, v in changes.items():
        if v is not None or k == "scheduled_at":
            setattr(i, k, v)
    audit(db, user, "interview_updated", "interview", i.id, {"fields": sorted(changes)}, client_ip(request))
    db.commit()
    return interview_out(i)
