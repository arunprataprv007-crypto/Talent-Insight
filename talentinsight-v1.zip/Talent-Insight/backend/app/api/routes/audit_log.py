"""Audit trail viewer (admins only)."""
from fastapi import APIRouter, Depends, Query
from sqlalchemy import select
from sqlalchemy.orm import Session, selectinload

from app.api.deps import require_roles
from app.api.serializers import iso
from app.db.models import AuditLog, User
from app.db.session import get_db

router = APIRouter(prefix="/audit", tags=["audit"])


@router.get("")
def list_audit(limit: int = Query(200, ge=1, le=1000), action: str = "",
               _: User = Depends(require_roles("admin")), db: Session = Depends(get_db)) -> list[dict]:
    stmt = select(AuditLog).options(selectinload(AuditLog.user)).order_by(AuditLog.id.desc()).limit(limit)
    if action:
        stmt = stmt.where(AuditLog.action == action)
    return [{"id": r.id, "action": r.action, "entity": r.entity, "entity_id": r.entity_id, "detail": r.detail,
             "ip": r.ip, "user": r.user.full_name if r.user else None, "created_at": iso(r.created_at)}
            for r in db.scalars(stmt)]
