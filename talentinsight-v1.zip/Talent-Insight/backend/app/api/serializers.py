"""Turns database rows into JSON-friendly dictionaries for the frontend."""
from app.db.models import Application, Candidate, Interview, Job, Note, User


def iso(d):
    return d.isoformat() if d else None


def user_out(u: User) -> dict:
    return {"id": u.id, "email": u.email, "full_name": u.full_name, "role": u.role,
            "is_active": u.is_active, "created_at": iso(u.created_at), "last_login_at": iso(u.last_login_at)}


def candidate_summary(c: Candidate) -> dict:
    return {"id": c.id, "full_name": c.full_name, "email": c.email, "current_title": c.current_title,
            "current_company": c.current_company, "location": c.location,
            "years_experience": c.years_experience, "skills": c.skills or [], "tags": c.tags or [],
            "source": c.source, "consent_status": c.consent_status, "created_at": iso(c.created_at),
            "stages": sorted({a.stage for a in c.applications})}


def note_out(n: Note) -> dict:
    return {"id": n.id, "body": n.body, "created_at": iso(n.created_at),
            "author": n.author.full_name if n.author else "Former user"}


def application_out(a: Application, include_candidate: bool = False, include_job: bool = False) -> dict:
    out = {"id": a.id, "candidate_id": a.candidate_id, "job_id": a.job_id, "stage": a.stage,
           "match_score": a.match_score, "match_analysis": a.match_analysis,
           "stage_changed_at": iso(a.stage_changed_at), "created_at": iso(a.created_at),
           "interviews": [interview_out(i) for i in a.interviews]}
    if include_candidate:
        out["candidate"] = {"id": a.candidate.id, "full_name": a.candidate.full_name,
                            "current_title": a.candidate.current_title, "skills": a.candidate.skills or []}
    if include_job:
        out["job"] = {"id": a.job.id, "title": a.job.title, "status": a.job.status}
    return out


def candidate_detail(c: Candidate) -> dict:
    out = candidate_summary(c)
    out.update({
        "phone": c.phone, "linkedin_url": c.linkedin_url, "summary": c.summary,
        "education": c.education or [], "experience": c.experience or [], "parse_method": c.parse_method,
        "updated_at": iso(c.updated_at),
        "resumes": [{"id": r.id, "filename": r.filename, "size_bytes": r.size_bytes,
                     "created_at": iso(r.created_at)} for r in c.resumes],
        "resume_text": c.resumes[0].text if c.resumes else "",
        "notes": [note_out(n) for n in c.notes],
        "applications": [application_out(a, include_job=True) for a in c.applications],
    })
    return out


def job_out(j: Job, with_pipeline: bool = False) -> dict:
    counts: dict[str, int] = {}
    for a in j.applications:
        counts[a.stage] = counts.get(a.stage, 0) + 1
    out = {"id": j.id, "title": j.title, "department": j.department, "location": j.location,
           "employment_type": j.employment_type, "salary_range": j.salary_range, "description": j.description,
           "must_have_skills": j.must_have_skills or [], "nice_to_have_skills": j.nice_to_have_skills or [],
           "boolean_string": j.boolean_string, "status": j.status, "hiring_manager_id": j.hiring_manager_id,
           "hiring_manager": j.hiring_manager.full_name if j.hiring_manager else None,
           "created_at": iso(j.created_at), "stage_counts": counts, "total_applications": len(j.applications)}
    if with_pipeline:
        out["applications"] = [application_out(a, include_candidate=True) for a in j.applications]
    return out


def interview_out(i: Interview) -> dict:
    return {"id": i.id, "application_id": i.application_id, "scheduled_at": iso(i.scheduled_at),
            "interviewer_name": i.interviewer_name, "mode": i.mode, "status": i.status, "kit": i.kit,
            "scorecard": i.scorecard, "created_at": iso(i.created_at)}
