"""
The single place the app talks to an AI provider (the "adapter").

To switch providers later, only this file changes. It also enforces the monthly
token budget and records token usage for every call.
"""
import json
import logging
from datetime import datetime, timezone

from sqlalchemy import func, select
from sqlalchemy.orm import Session

from app.core.config import settings
from app.db.models import AIUsage

logger = logging.getLogger(__name__)


class AIUnavailable(Exception):
    """AI is not configured, over budget, or the provider failed. Callers fall back to rules."""


def ai_enabled() -> bool:
    return bool(settings.openai_api_key)


def tokens_used_this_month(db: Session) -> int:
    now = datetime.now(timezone.utc)
    start = now.replace(day=1, hour=0, minute=0, second=0, microsecond=0)
    total = db.scalar(
        select(func.coalesce(func.sum(AIUsage.prompt_tokens + AIUsage.completion_tokens), 0))
        .where(AIUsage.created_at >= start)
    )
    return int(total or 0)


_client = None


def _get_client():
    global _client
    if _client is None:
        from openai import OpenAI  # imported lazily so the app runs without the package configured
        _client = OpenAI(api_key=settings.openai_api_key, base_url=settings.openai_base_url or None,
                         timeout=60, max_retries=2)
    return _client


def complete(db: Session, *, feature: str, system: str, user: str, user_id: int | None,
             json_mode: bool = False, max_tokens: int = 1500) -> str:
    if not ai_enabled():
        raise AIUnavailable("AI is not configured")
    if tokens_used_this_month(db) >= settings.ai_monthly_token_budget:
        logger.warning("Monthly AI token budget reached; using fallback for %s", feature)
        raise AIUnavailable("Monthly AI budget reached")

    kwargs = {
        "model": settings.openai_model,
        "messages": [{"role": "system", "content": system}, {"role": "user", "content": user}],
        "max_completion_tokens": max_tokens,
    }
    if json_mode:
        kwargs["response_format"] = {"type": "json_object"}
    try:
        resp = _get_client().chat.completions.create(**kwargs)
    except Exception as exc:
        logger.error("AI call failed for %s: %s", feature, type(exc).__name__)
        raise AIUnavailable(str(exc)) from exc

    usage = getattr(resp, "usage", None)
    db.add(AIUsage(user_id=user_id, feature=feature, model=settings.openai_model,
                   prompt_tokens=getattr(usage, "prompt_tokens", 0) or 0,
                   completion_tokens=getattr(usage, "completion_tokens", 0) or 0))
    db.commit()
    content = (resp.choices[0].message.content or "").strip()
    if not content:
        raise AIUnavailable("Empty AI response")
    return content


def complete_json(db: Session, **kwargs) -> dict:
    text = complete(db, json_mode=True, **kwargs)
    text = text.removeprefix("```json").removeprefix("```").removesuffix("```").strip()
    try:
        data = json.loads(text)
    except json.JSONDecodeError as exc:
        raise AIUnavailable("AI returned invalid JSON") from exc
    if not isinstance(data, dict):
        raise AIUnavailable("AI returned unexpected JSON")
    return data
