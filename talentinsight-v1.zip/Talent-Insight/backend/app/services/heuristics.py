"""
Rule-based fallbacks.

These run when AI isn't configured, is over budget, or fails. They make sure every
feature still works, just less cleverly. They're also cheap and instant.
"""
import re

SKILL_LEXICON = [
    # Engineering
    "Python", "Java", "JavaScript", "TypeScript", "C#", "C++", "Golang", "Rust", "Ruby", "PHP", "Kotlin", "Swift",
    "Scala", "SQL", "NoSQL", "HTML", "CSS", "React", "Angular", "Vue", "Next.js", "Node.js", "Express",
    "Django", "Flask", "FastAPI", "Spring Boot", "Spring", ".NET", "ASP.NET", "Laravel", "Rails",
    "PostgreSQL", "MySQL", "MongoDB", "Redis", "Elasticsearch", "Oracle", "SQL Server", "Snowflake",
    "AWS", "Azure", "GCP", "Docker", "Kubernetes", "Terraform", "Ansible", "Jenkins", "GitHub Actions",
    "CI/CD", "Linux", "Git", "REST APIs", "GraphQL", "Microservices", "Kafka", "RabbitMQ", "Spark",
    "Hadoop", "Airflow", "dbt", "Tableau", "Power BI", "Excel", "Machine Learning", "Deep Learning",
    "NLP", "LLM", "TensorFlow", "PyTorch", "scikit-learn", "Pandas", "Data Analysis", "Data Engineering",
    "DevOps", "SRE", "Security", "Networking", "Salesforce", "SAP", "ServiceNow", "Selenium", "Cypress",
    "QA", "Agile", "Scrum", "JIRA", "Product Management", "UX", "Figma",
    # Talent acquisition & business
    "Sourcing", "Headhunting", "Boolean Search", "LinkedIn Recruiter", "Stakeholder Management",
    "Team Leadership", "People Management", "Employer Branding", "Campus Hiring", "Executive Search",
    "Talent Mapping", "Workday", "SuccessFactors", "Greenhouse", "Lever", "Taleo", "iCIMS", "Bullhorn",
    "Onboarding", "Offer Negotiation", "Compensation", "HR Analytics", "Diversity Hiring", "RPO", "MSP",
    "Vendor Management", "Account Management", "Business Development", "Sales", "Negotiation",
    "Project Management", "Program Management", "Communication", "Leadership", "Immigration",
]

EMAIL_RE = re.compile(r"[\w.+-]+@[\w-]+\.[\w.-]+")
PHONE_RE = re.compile(r"(\+?\d[\d \t().-]{8,}\d)")
LINKEDIN_RE = re.compile(r"(https?://)?(www\.)?linkedin\.com/in/[\w\-%]+/?", re.I)
YEARS_RE = re.compile(r"(\d{1,2}(?:\.\d)?)\s*\+?\s*(?:years|yrs)", re.I)


def _skill_pattern(skill: str) -> re.Pattern:
    # Very short names like "Go" or "R" are matched case-sensitively to avoid false hits on ordinary words.
    flags = 0 if len(skill) <= 2 else re.I
    return re.compile(r"(?<![\w+#.])" + re.escape(skill) + r"(?![\w+#])", flags)


_SKILL_PATTERNS = [(s, _skill_pattern(s)) for s in SKILL_LEXICON]


def extract_skills(text: str) -> list[str]:
    found = [s for s, pat in _SKILL_PATTERNS if pat.search(text or "")]
    # Drop "Spring" if "Spring Boot" found, etc.
    return [s for s in found if not any(o != s and o.lower().startswith(s.lower() + " ") for o in found)]


def _is_phone(candidate: str) -> bool:
    digits = sum(ch.isdigit() for ch in candidate)
    return 10 <= digits <= 15


def find_phone(text: str) -> str | None:
    for m in PHONE_RE.finditer(text or ""):
        if _is_phone(m.group(0)):
            return m.group(0).strip()
    return None


def redact_contact_details(text: str) -> str:
    """Remove emails, phone numbers and LinkedIn URLs before sending text to an AI provider."""
    text = EMAIL_RE.sub("[email]", text or "")
    text = LINKEDIN_RE.sub("[linkedin]", text)
    return PHONE_RE.sub(lambda m: "[phone]" if _is_phone(m.group(0)) else m.group(0), text)


def _guess_name(lines: list[str]) -> str | None:
    for line in lines[:8]:
        clean = line.strip()
        if EMAIL_RE.search(clean) or any(ch.isdigit() for ch in clean):
            continue
        words = clean.replace(",", " ").split()
        if 2 <= len(words) <= 4 and all(w[:1].isalpha() and w[:1].isupper() for w in words) and len(clean) <= 60:
            return clean
    return None


def parse_resume_rules(text: str) -> dict:
    lines = [ln.strip() for ln in (text or "").splitlines() if ln.strip()]
    email = EMAIL_RE.search(text or "")
    linkedin = LINKEDIN_RE.search(text or "")
    years = [float(y) for y in YEARS_RE.findall(text or "") if float(y) <= 50]
    name = _guess_name(lines)
    title = None
    if name and name in lines:
        idx = lines.index(name)
        if idx + 1 < len(lines) and len(lines[idx + 1]) <= 80 and not EMAIL_RE.search(lines[idx + 1]):
            title = lines[idx + 1]
    return {
        "full_name": name,
        "email": email.group(0) if email else None,
        "phone": find_phone(text),
        "linkedin_url": linkedin.group(0) if linkedin else None,
        "current_title": title,
        "current_company": None,
        "location": None,
        "years_experience": max(years) if years else None,
        "skills": extract_skills(text),
        "education": [],
        "experience": [],
        "summary": " ".join(
            ln for ln in lines[:12]
            if ln not in (name, title) and not EMAIL_RE.search(ln) and not find_phone(ln)
            and not LINKEDIN_RE.search(ln)
        )[:500] or None,
    }


def keyword_match(candidate_skills: list[str], candidate_text: str,
                  must_have: list[str], nice_to_have: list[str]) -> dict:
    """Transparent skill-overlap score. 80% weight on must-haves, 20% on nice-to-haves."""
    haystack = " ".join(candidate_skills or []) + " " + (candidate_text or "")

    def present(skill: str) -> bool:
        return bool(_skill_pattern(skill).search(haystack))

    must_hit = [s for s in must_have if present(s)]
    nice_hit = [s for s in nice_to_have if present(s)]
    must_score = (len(must_hit) / len(must_have)) if must_have else 1.0
    nice_score = (len(nice_hit) / len(nice_to_have)) if nice_to_have else 0.0
    weight_nice = 0.2 if nice_to_have else 0.0
    score = round(100 * ((1 - weight_nice) * must_score + weight_nice * nice_score))
    gaps = [s for s in must_have if s not in must_hit]
    if score >= 75:
        rec = "Consider for screening"
    elif score >= 50:
        rec = "Possible fit, review gaps"
    else:
        rec = "Limited skill overlap"
    return {
        "score": score,
        "summary": f"Matched {len(must_hit)}/{len(must_have)} must-have and "
                   f"{len(nice_hit)}/{len(nice_to_have)} nice-to-have skills by keyword.",
        "strengths": must_hit + nice_hit,
        "gaps": gaps,
        "evidence": [f"'{s}' appears in the profile or CV" for s in must_hit + nice_hit],
        "interview_focus": [f"Probe depth of experience with {s}" for s in (gaps or must_hit)[:4]],
        "recommendation": rec,
    }


def _q(term: str) -> str:
    term = term.strip()
    return f'"{term}"' if " " in term or "." in term or "/" in term else term


def boolean_rules(title: str, must_have: list[str], nice_to_have: list[str],
                  exclude: list[str], location: str | None = None) -> dict:
    title = title.strip()
    base = re.sub(r"^(senior|sr\.?|junior|jr\.?|lead|principal|staff)\s+", "", title, flags=re.I)
    titles = list(dict.fromkeys([title, base] + ([f"Senior {base}", f"Lead {base}"] if base != title else [])))
    parts = ["(" + " OR ".join(_q(t) for t in titles if t) + ")"]
    parts += [_q(s) for s in must_have if s.strip()]
    if nice_to_have:
        parts.append("(" + " OR ".join(_q(s) for s in nice_to_have if s.strip()) + ")")
    query = " AND ".join(parts)
    if exclude:
        query += " NOT (" + " OR ".join(_q(s) for s in exclude if s.strip()) + ")"
    broad = " AND ".join(["(" + " OR ".join(_q(t) for t in titles) + ")"] + [_q(s) for s in must_have[:2]])
    tips = ["Start with the full string; if results are too few, use the broader version.",
            "LinkedIn Recruiter supports AND, OR, NOT, quotes and brackets. Keep operators in CAPITALS."]
    if location:
        tips.append(f"Apply '{location}' using the platform's location filter rather than in the string.")
    return {"boolean": query, "variations": [broad], "tips": tips}


EMAIL_TEMPLATES = {
    "outreach": ("Opportunity: {role} at {company}",
                 "Hi {name},\n\nI came across your profile and thought your background could be a strong fit for a "
                 "{role} opportunity with {company}.\n\n{details}\n\nWould you be open to a 15-minute call this week "
                 "to hear more? Happy to work around your schedule.\n\nBest regards,\n{recruiter}"),
    "interview_invite": ("Interview invitation: {role} at {company}",
                         "Hi {name},\n\nThank you for your interest in the {role} role at {company}. We'd like to "
                         "invite you to an interview.\n\n{details}\n\nPlease reply with a few times that suit you and "
                         "I'll confirm the details.\n\nBest regards,\n{recruiter}"),
    "offer_intro": ("Great news about the {role} role at {company}",
                    "Hi {name},\n\nI'm pleased to let you know that {company} would like to make you an offer for "
                    "the {role} position.\n\n{details}\n\nI'll share the formal offer letter separately. Let's set "
                    "up a quick call to walk through it and answer any questions.\n\nBest regards,\n{recruiter}"),
    "rejection": ("Update on your application: {role}",
                  "Hi {name},\n\nThank you for the time you invested in applying for the {role} role at {company}. "
                  "After careful consideration, we've decided not to move forward with your application on this "
                  "occasion.\n\n{details}\n\nWe appreciated learning about your experience and would be glad to "
                  "keep in touch about future roles.\n\nKind regards,\n{recruiter}"),
    "follow_up": ("Following up: {role} at {company}",
                  "Hi {name},\n\nI wanted to follow up on my earlier message about the {role} role at {company}."
                  "\n\n{details}\n\nIf the timing isn't right, no problem at all. Just let me know.\n\n"
                  "Best regards,\n{recruiter}"),
}


def email_rules(purpose: str, name: str, role: str, company: str, recruiter: str, details: str) -> dict:
    subject, body = EMAIL_TEMPLATES.get(purpose, EMAIL_TEMPLATES["outreach"])
    values = {"name": name or "there", "role": role or "the role", "company": company or "our client",
              "recruiter": recruiter or "", "details": details.strip() or ""}
    body = body.format(**values).replace("\n\n\n\n", "\n\n")
    return {"subject": subject.format(**values), "body": body}


def jd_rules(title: str, department: str, location: str, seniority: str, skills: list[str],
             notes: str, company: str) -> str:
    skill_lines = "\n".join(f"- Hands-on experience with {s}" for s in skills) or "- Relevant hands-on experience"
    return (
        f"# {title}\n\n"
        f"**Company:** {company or '[Company]'}  \n**Department:** {department or '[Department]'}  \n"
        f"**Location:** {location or '[Location]'}  \n**Level:** {seniority or '[Level]'}\n\n"
        f"## About the role\nWe're looking for a {title} to join our {department or ''} team. "
        f"{notes.strip()}\n\n"
        "## What you'll do\n- Own key deliverables for the team and see them through to completion\n"
        "- Work closely with stakeholders to understand needs and priorities\n"
        "- Share knowledge and help raise the bar for the wider team\n\n"
        f"## What you'll bring\n{skill_lines}\n- Clear communication and a collaborative approach\n\n"
        "## What we offer\n- Competitive compensation\n- Learning and development support\n"
        "- An inclusive team where different backgrounds are valued\n\n"
        "_We welcome applications from everyone and make hiring decisions based on skills and experience._"
    )


def interview_kit_rules(role: str, skills: list[str], seniority: str) -> dict:
    questions = [
        {"question": f"Walk me through a recent project where you used {s}. What was your specific contribution?",
         "competency": s, "what_good_looks_like": f"Concrete example, clear personal role, depth in {s}."}
        for s in skills[:5]
    ]
    questions += [
        {"question": "Tell me about a time you disagreed with a stakeholder. How did you handle it?",
         "competency": "Collaboration", "what_good_looks_like": "Listens, uses evidence, reaches a workable outcome."},
        {"question": "Describe a mistake you made at work and what you changed afterwards.",
         "competency": "Ownership", "what_good_looks_like": "Takes responsibility, shows specific learning."},
        {"question": f"What would you want to achieve in your first 90 days as a {role}?",
         "competency": "Role understanding", "what_good_looks_like": "Realistic, prioritised, aligned to the role."},
    ]
    criteria = list(dict.fromkeys(skills[:5] + ["Communication", "Collaboration", "Ownership"]))
    return {"questions": questions, "scorecard_criteria": criteria,
            "guidance": "Ask every candidate for this role the same core questions and score against the criteria."}
