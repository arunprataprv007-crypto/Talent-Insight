"""Reads text out of uploaded CV files (PDF, DOCX, TXT) safely."""
import io
import logging

logger = logging.getLogger(__name__)

ALLOWED = {
    ".pdf": "application/pdf",
    ".docx": "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
    ".txt": "text/plain",
}
MAX_TEXT_CHARS = 60_000


class FileRejected(ValueError):
    """Raised with a user-friendly message when a file can't be accepted."""


def file_extension(filename: str) -> str:
    name = (filename or "").lower().strip()
    return name[name.rfind("."):] if "." in name else ""


def validate_file(filename: str, data: bytes, max_bytes: int) -> str:
    """Check type and size. Returns the content type. Checks real file contents, not just the name."""
    ext = file_extension(filename)
    if ext == ".doc":
        raise FileRejected("Old .doc files aren't supported. Save it as .docx or PDF and upload again.")
    if ext not in ALLOWED:
        raise FileRejected("Only PDF, DOCX and TXT files are accepted.")
    if len(data) == 0:
        raise FileRejected("The file is empty.")
    if len(data) > max_bytes:
        raise FileRejected(f"File is larger than {max_bytes // (1024 * 1024)} MB.")
    if ext == ".pdf" and not data.startswith(b"%PDF"):
        raise FileRejected("This file is named .pdf but isn't a real PDF.")
    if ext == ".docx" and not data.startswith(b"PK"):
        raise FileRejected("This file is named .docx but isn't a real Word document.")
    return ALLOWED[ext]


def extract_text(filename: str, data: bytes) -> str:
    ext = file_extension(filename)
    try:
        if ext == ".pdf":
            from pypdf import PdfReader
            reader = PdfReader(io.BytesIO(data))
            text = "\n".join((page.extract_text() or "") for page in reader.pages[:30])
        elif ext == ".docx":
            import docx
            document = docx.Document(io.BytesIO(data))
            parts = [p.text for p in document.paragraphs]
            for table in document.tables:
                for row in table.rows:
                    parts.append(" | ".join(cell.text for cell in row.cells))
            text = "\n".join(parts)
        else:
            text = data.decode("utf-8", errors="replace")
    except Exception as exc:  # corrupted or password-protected files
        logger.warning("Could not read %s: %s", ext, exc)
        raise FileRejected("The file couldn't be read. It may be damaged or password-protected.") from exc

    text = text.replace("\x00", "").strip()
    if not text:
        raise FileRejected("No text found. If this is a scanned image PDF, upload a text-based version.")
    return text[:MAX_TEXT_CHARS]
