"""Records important actions in the audit log. The caller commits the transaction."""
from sqlalchemy.orm import Session

from app.db.models import AuditLog, User


def audit(db: Session, user: User | None, action: str, entity: str | None = None,
          entity_id: int | None = None, detail: dict | None = None, ip: str | None = None) -> None:
    db.add(AuditLog(user_id=user.id if user else None, action=action, entity=entity,
                    entity_id=entity_id, detail=detail, ip=ip))
