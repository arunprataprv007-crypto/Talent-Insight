/* TalentInsight web app.
 * One page, many "views". The part after # in the address (e.g. #/candidates) decides which view shows.
 * All data comes from the backend API at /api. All text from the server is escaped before display
 * (the esc() function) so nobody can inject code through a CV or a name.
 */
"use strict";

// ---------- Helpers ----------
const $ = (sel, el = document) => el.querySelector(sel);
const $$ = (sel, el = document) => Array.from(el.querySelectorAll(sel));
const esc = (v) => String(v ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
const splitList = (s) => String(s || "").split(/[,\n]/).map((x) => x.trim()).filter(Boolean);
const fmtDate = (iso) => (iso ? new Date(iso).toLocaleDateString(undefined, { day: "numeric", month: "short", year: "numeric" }) : "—");
const fmtDateTime = (iso) => (iso ? new Date(iso).toLocaleString(undefined, { day: "numeric", month: "short", hour: "2-digit", minute: "2-digit" }) : "Not set");

const STAGES = ["sourced", "screening", "shortlisted", "interview", "offer", "hired", "rejected"];
const STAGE_LABEL = { sourced: "Sourced", screening: "Screening", shortlisted: "Shortlisted", interview: "Interview", offer: "Offer", hired: "Hired", rejected: "Rejected" };
const ROLE_LABEL = { admin: "Admin", recruiter: "Recruiter", hiring_manager: "Hiring manager" };
const CONSENT_LABEL = { not_recorded: "Not recorded", consented: "Consented", withdrawn: "Withdrawn" };

const state = { user: null, ai: null, chat: [] };
const isStaff = () => state.user && ["admin", "recruiter"].includes(state.user.role);
const isAdmin = () => state.user && state.user.role === "admin";

class ApiError extends Error { constructor(msg, status) { super(msg); this.status = status; } }

function formatDetail(data) {
  if (!data) return "Request failed.";
  if (typeof data === "string") return data.slice(0, 300);
  const d = data.detail;
  if (Array.isArray(d)) return d.map((e) => `${(e.loc || []).slice(1).join(".")}: ${e.msg}`).join("; ");
  return d || "Request failed.";
}

async function api(path, { method = "GET", body, form } = {}) {
  const opts = { method, credentials: "same-origin", headers: { "X-Requested-With": "TalentInsight" } };
  if (form) opts.body = form;
  else if (body !== undefined) { opts.headers["Content-Type"] = "application/json"; opts.body = JSON.stringify(body); }
  let res;
  try { res = await fetch("/api" + path, opts); }
  catch { throw new ApiError("Can't reach the server. Check your connection.", 0); }
  const isJson = (res.headers.get("content-type") || "").includes("json");
  const data = isJson ? await res.json() : await res.text();
  if (res.status === 401 && !path.startsWith("/auth/")) { state.user = null; renderLogin("Your session ended. Please sign in again."); }
  if (!res.ok) throw new ApiError(formatDetail(data), res.status);
  return data;
}

function toast(msg, type = "") {
  const t = document.createElement("div");
  t.className = "toast " + type;
  t.textContent = msg;
  $("#toasts").appendChild(t);
  setTimeout(() => t.remove(), type === "error" ? 6000 : 3000);
}
const fail = (e) => toast(e.message || String(e), "error");

async function withBusy(btn, fn) {
  const label = btn ? btn.textContent : "";
  if (btn) { btn.disabled = true; btn.textContent = "Working…"; }
  try { return await fn(); } catch (e) { fail(e); } finally { if (btn) { btn.disabled = false; btn.textContent = label; } }
}

async function copy(text) {
  try { await navigator.clipboard.writeText(text); toast("Copied to clipboard"); }
  catch { toast("Couldn't copy automatically. Select the text and copy it.", "error"); }
}

function formData(form) {
  const o = {};
  new FormData(form).forEach((v, k) => { o[k] = typeof v === "string" ? v.trim() : v; });
  return o;
}

function nullIfEmpty(o) { for (const k in o) if (o[k] === "") o[k] = null; return o; }

// Very small, safe Markdown renderer (escapes first, then adds formatting)
function md(text) {
  const lines = esc(text).split("\n");
  let html = "", inList = false;
  for (const raw of lines) {
    let line = raw.replace(/\*\*(.+?)\*\*/g, "<strong>$1</strong>").replace(/_(.+?)_/g, "<em>$1</em>");
    const li = line.match(/^\s*[-*]\s+(.*)/);
    if (li) { if (!inList) { html += "<ul>"; inList = true; } html += `<li>${li[1]}</li>`; continue; }
    if (inList) { html += "</ul>"; inList = false; }
    if (/^###\s/.test(line)) html += `<h3>${line.slice(4)}</h3>`;
    else if (/^##\s/.test(line)) html += `<h2>${line.slice(3)}</h2>`;
    else if (/^#\s/.test(line)) html += `<h1>${line.slice(2)}</h1>`;
    else if (line.trim()) html += `<p>${line}</p>`;
  }
  return html + (inList ? "</ul>" : "");
}

const chips = (arr, max = 99) => (arr || []).slice(0, max).map((s) => `<span class="chip">${esc(s)}</span>`).join("") +
  ((arr || []).length > max ? `<span class="chip">+${arr.length - max}</span>` : "");
const stageBadge = (s) => `<span class="badge stage-${esc(s)}">${esc(STAGE_LABEL[s] || s)}</span>`;
const scoreBadge = (n) => (n == null ? `<span class="muted small">Not run</span>` : `<span class="score ${n >= 75 ? "high" : n >= 50 ? "mid" : ""}" title="Match score">${n}</span>`);
const methodBadge = (m) => (m === "ai" ? `<span class="badge ai">AI draft — review before use</span>` : `<span class="badge rules">Rule-based draft</span>`);
const stageOptions = (cur) => STAGES.map((s) => `<option value="${s}" ${s === cur ? "selected" : ""}>${STAGE_LABEL[s]}</option>`).join("");
const empty = (title, text = "", action = "") => `<div class="empty"><strong>${esc(title)}</strong>${esc(text)}${action ? `<div style="margin-top:12px">${action}</div>` : ""}</div>`;

// ---------- Modal ----------
function openModal(html, { wide = false } = {}) {
  const root = $("#modal-root");
  root.innerHTML = `<div class="overlay"><div class="modal ${wide ? "wide" : ""}" role="dialog" aria-modal="true">${html}</div></div>`;
  const overlay = $(".overlay", root);
  overlay.addEventListener("click", (e) => { if (e.target === overlay || e.target.closest("[data-close]")) closeModal(); });
  document.addEventListener("keydown", escClose);
  const first = $("input, select, textarea, button", root);
  if (first) first.focus();
  return $(".modal", root);
}
function escClose(e) { if (e.key === "Escape") closeModal(); }
function closeModal() { $("#modal-root").innerHTML = ""; document.removeEventListener("keydown", escClose); }
const modalHead = (title) => `<div class="modal-head"><h2>${esc(title)}</h2><button class="btn ghost sm" data-close aria-label="Close">✕</button></div>`;

// ---------- Icons (inline SVG, no external requests) ----------
const I = (d) => `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${d}</svg>`;
const ICON = {
  dash: I('<rect x="3" y="3" width="7" height="9"/><rect x="14" y="3" width="7" height="5"/><rect x="14" y="12" width="7" height="9"/><rect x="3" y="16" width="7" height="5"/>'),
  people: I('<circle cx="9" cy="8" r="3.5"/><path d="M2.5 20c.8-3.5 3.4-5.5 6.5-5.5s5.7 2 6.5 5.5"/><path d="M16 4.5a3.5 3.5 0 0 1 0 7M18 14.8c1.8.8 3 2.6 3.5 5.2"/>'),
  upload: I('<path d="M12 16V4M7 9l5-5 5 5"/><path d="M4 16v3a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2v-3"/>'),
  jobs: I('<rect x="3" y="7" width="18" height="13" rx="2"/><path d="M8 7V5a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2M3 13h18"/>'),
  cal: I('<rect x="3" y="5" width="18" height="16" rx="2"/><path d="M3 10h18M8 3v4M16 3v4"/>'),
  doc: I('<path d="M14 3H6a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V9z"/><path d="M14 3v6h6M8 13h8M8 17h5"/>'),
  search: I('<circle cx="11" cy="11" r="7"/><path d="m20 20-3.5-3.5"/>'),
  mail: I('<rect x="3" y="5" width="18" height="14" rx="2"/><path d="m3 7 9 6 9-6"/>'),
  q: I('<circle cx="12" cy="12" r="9"/><path d="M9.5 9.5a2.5 2.5 0 1 1 3.5 2.3c-.6.3-1 .9-1 1.6V14M12 17.5v.01"/>'),
  chat: I('<path d="M21 12a8 8 0 0 1-11.6 7.1L4 20l1-4.6A8 8 0 1 1 21 12z"/>'),
  chart: I('<path d="M4 20V10M10 20V4M16 20v-7M22 20H2"/>'),
  users: I('<circle cx="12" cy="8" r="4"/><path d="M4 21c1-4 4.3-6 8-6s7 2 8 6"/>'),
  log: I('<path d="M8 6h13M8 12h13M8 18h13M3 6h.01M3 12h.01M3 18h.01"/>'),
};

// ---------- Shell ----------
function navItems() {
  const items = [
    ["Workspace"],
    ["#/dashboard", "Dashboard", ICON.dash],
    ["#/candidates", "Candidates", ICON.people],
    isStaff() && ["#/upload", "Upload CVs", ICON.upload],
    ["#/jobs", "Jobs", ICON.jobs],
    ["#/interviews", "Interviews", ICON.cal],
    ["#/analytics", "Analytics", ICON.chart],
    ["AI tools"],
    isStaff() && ["#/tools/jd", "JD generator", ICON.doc],
    isStaff() && ["#/tools/boolean", "Boolean search", ICON.search],
    isStaff() && ["#/tools/email", "Email writer", ICON.mail],
    ["#/tools/interview", "Interview kit", ICON.q],
    ["#/chat", "Assistant", ICON.chat],
    isAdmin() && ["Admin"],
    isAdmin() && ["#/admin/users", "Team & roles", ICON.users],
    isAdmin() && ["#/admin/audit", "Audit log", ICON.log],
  ].filter(Boolean);
  return items.map((it) => (it.length === 1 ? `<div class="nav-group">${esc(it[0])}</div>`
    : `<a href="${it[0]}" data-nav="${it[0]}">${it[2]}<span>${esc(it[1])}</span></a>`)).join("");
}

function renderShell() {
  const u = state.user;
  const ai = state.ai;
  $("#app").innerHTML = `
  <div class="shell">
    <aside class="sidebar" id="sidebar">
      <div class="brand"><div class="brand-mark">TI</div><div class="brand-name">TalentInsight</div></div>
      <nav class="nav" aria-label="Main">${navItems()}</nav>
    </aside>
    <div class="main">
      <header class="topbar">
        <button class="btn ghost menu-btn" id="menu-btn" aria-label="Open menu">☰ Menu</button>
        <span class="badge ${ai && ai.enabled ? "ai" : "rules"}" title="${ai && ai.enabled ? "AI features use " + esc(ai.model) : "No AI key configured: features use rule-based fallbacks"}">${ai && ai.enabled ? "AI on" : "AI off (rules mode)"}</span>
        <button class="btn ghost sm" id="theme-btn" aria-label="Switch light or dark mode">${document.documentElement.dataset.theme === "dark" ? "Light mode" : "Dark mode"}</button>
        <a class="btn ghost sm" href="#/account">${esc(u.full_name)} · ${esc(ROLE_LABEL[u.role])}</a>
        <button class="btn sm" id="logout-btn">Sign out</button>
      </header>
      <main class="view" id="view" tabindex="-1"></main>
    </div>
  </div>`;
  $("#theme-btn").addEventListener("click", (e) => {
    const next = document.documentElement.dataset.theme === "dark" ? "light" : "dark";
    document.documentElement.dataset.theme = next;
    try { localStorage.setItem("ti-theme", next); } catch {}
    e.target.textContent = next === "dark" ? "Light mode" : "Dark mode";
  });
  $("#logout-btn").addEventListener("click", async () => { await api("/auth/logout", { method: "POST" }).catch(() => {}); state.user = null; location.hash = ""; renderLogin(); });
  $("#menu-btn").addEventListener("click", () => $("#sidebar").classList.toggle("open"));
}

function renderLogin(message = "") {
  closeModal();
  $("#app").innerHTML = `
  <div class="login">
    <section class="login-art">
      <div class="brand"><div class="brand-mark" style="background:var(--accent-ink);color:var(--accent)">TI</div><div class="brand-name">TalentInsight</div></div>
      <div>
        <h1>Every candidate, every role, one clear pipeline.</h1>
        <p>Parse CVs, match them to jobs, write outreach and plan interviews. AI does the drafting. You make the calls.</p>
      </div>
      <p class="small">Access is restricted to authorised team members. Activity is logged.</p>
    </section>
    <section class="login-form">
      <form id="login-form" novalidate>
        <h2 style="font-size:1.35rem;margin-bottom:6px">Sign in</h2>
        <p class="muted">Use the account your administrator gave you.</p>
        ${message ? `<div class="notice">${esc(message)}</div>` : ""}
        <div class="field"><label for="email">Work email</label><input id="email" name="email" type="email" autocomplete="username" required></div>
        <div class="field"><label for="password">Password</label><input id="password" name="password" type="password" autocomplete="current-password" required></div>
        <button class="btn primary" style="width:100%" type="submit">Sign in</button>
        <p class="small muted" id="login-error" role="alert" style="margin-top:10px"></p>
      </form>
    </section>
  </div>`;
  $("#login-form").addEventListener("submit", async (e) => {
    e.preventDefault();
    const btn = $("button[type=submit]", e.target);
    btn.disabled = true;
    try {
      state.user = await api("/auth/login", { method: "POST", body: formData(e.target) });
      await startApp();
    } catch (err) { $("#login-error").textContent = err.message; }
    finally { btn.disabled = false; }
  });
}

// ---------- Router ----------
const routes = [
  [/^#\/dashboard$/, pageDashboard], [/^#\/candidates$/, pageCandidates], [/^#\/candidates\/(\d+)$/, pageCandidate],
  [/^#\/upload$/, pageUpload], [/^#\/jobs$/, pageJobs], [/^#\/jobs\/(\d+)$/, pageJob],
  [/^#\/interviews$/, pageInterviews], [/^#\/analytics$/, pageAnalytics],
  [/^#\/tools\/jd$/, pageJD], [/^#\/tools\/boolean$/, pageBoolean], [/^#\/tools\/email$/, pageEmail],
  [/^#\/tools\/interview$/, pageKit], [/^#\/chat$/, pageChat],
  [/^#\/admin\/users$/, pageUsers], [/^#\/admin\/audit$/, pageAudit], [/^#\/account$/, pageAccount],
];

async function route() {
  if (!state.user) return;
  const hash = location.hash || "#/dashboard";
  const view = $("#view");
  if (!view) return;
  $$(".nav a").forEach((a) => a.classList.toggle("active", hash === a.dataset.nav || hash.startsWith(a.dataset.nav + "/")));
  $("#sidebar")?.classList.remove("open");
  const match = routes.find(([re]) => re.test(hash));
  if (!match) { location.hash = "#/dashboard"; return; }
  view.innerHTML = `<p class="muted">Loading…</p>`;
  try { await match[1](view, ...hash.match(match[0]).slice(1)); }
  catch (e) {
    if (e.status === 401) return;
    view.innerHTML = empty(e.status === 404 ? "Not found" : e.status === 403 ? "No access" : "Something went wrong", " " + e.message);
  }
  view.focus({ preventScroll: true });
  window.scrollTo(0, 0);
}
window.addEventListener("hashchange", route);

async function startApp() {
  state.ai = await api("/ai/status").catch(() => ({ enabled: false }));
  renderShell();
  if (!location.hash || location.hash === "#/") location.hash = "#/dashboard";
  else route();
}

// ---------- Dashboard ----------
async function pageDashboard(view) {
  const [a, interviews, recent] = await Promise.all([api("/analytics/summary"), api("/interviews"), api("/candidates?limit=6")]);
  const t = a.totals;
  const upcoming = interviews.filter((i) => i.status === "scheduled").slice(0, 6);
  const max = Math.max(1, ...a.pipeline_by_stage.map((s) => s.count));
  view.innerHTML = `
  <div class="page-head"><div><h1>Good to see you, ${esc(state.user.full_name.split(" ")[0])}</h1><p>Here's where hiring stands today.</p></div>
    <div class="actions">${isStaff() ? `<a class="btn" href="#/upload">Upload CVs</a><a class="btn primary" href="#/jobs">Open jobs</a>` : ""}</div></div>
  <div class="stats">
    ${stat(t.candidates, "Candidates")}${stat(t.open_jobs, "Open jobs")}${stat(t.active_applications, "In active pipelines")}
    ${stat(t.upcoming_interviews, "Upcoming interviews")}${stat(t.hires_90d, "Hires, last 90 days")}${stat(t.avg_days_to_hire ?? "—", "Avg days to hire")}
  </div>
  <div class="grid cols-2">
    <section class="card"><h2>Pipeline by stage</h2><div class="bars">${a.pipeline_by_stage.map((s) => bar(STAGE_LABEL[s.stage], s.count, max)).join("")}</div></section>
    <section class="card"><div class="card-head"><h2>Upcoming interviews</h2><a class="small" href="#/interviews">See all</a></div>
      ${upcoming.length ? `<ul class="list-plain">${upcoming.map((i) => `<li><a href="#/candidates/${i.candidate.id}">${esc(i.candidate.full_name)}</a> <span class="muted">for</span> ${esc(i.job.title)}<div class="small muted">${fmtDateTime(i.scheduled_at)} · ${esc(i.interviewer_name || "Interviewer TBC")}</div></li>`).join("")}</ul>`
        : empty("No interviews scheduled", " Schedule one from a candidate's pipeline.")}</section>
    <section class="card" style="grid-column:1/-1"><div class="card-head"><h2>Recently added candidates</h2><a class="small" href="#/candidates">All candidates</a></div>
      ${candidateTable(recent.items)}</section>
  </div>`;
}
const stat = (v, l) => `<div class="stat"><div class="value">${esc(v)}</div><div class="label">${esc(l)}</div></div>`;
const bar = (label, n, max, suffix = "") => `<div class="bar-row"><span>${esc(label)}</span><div class="bar-track"><div class="bar-fill" style="width:${Math.round((n / max) * 100)}%"></div></div><span class="small">${esc(n)}${suffix}</span></div>`;

// ---------- Candidates ----------
function candidateTable(items) {
  if (!items.length) return empty("No candidates yet", " Upload CVs or add someone manually.");
  return `<div class="table-wrap"><table><thead><tr><th>Name</th><th>Current role</th><th>Skills</th><th>Source</th><th>Pipeline</th><th>Added</th></tr></thead><tbody>
  ${items.map((c) => `<tr><td><a href="#/candidates/${c.id}"><strong>${esc(c.full_name)}</strong></a>${c.email ? `<div class="small muted">${esc(c.email)}</div>` : ""}</td>
    <td>${esc(c.current_title || "—")}${c.current_company ? `<div class="small muted">${esc(c.current_company)}</div>` : ""}</td>
    <td><div class="chips">${chips(c.skills, 4)}</div></td><td>${esc(c.source)}</td>
    <td>${c.stages.map(stageBadge).join(" ") || `<span class="muted small">Not in a pipeline</span>`}</td><td class="small">${fmtDate(c.created_at)}</td></tr>`).join("")}
  </tbody></table></div>`;
}

async function pageCandidates(view) {
  let offset = 0, items = [], timer;
  view.innerHTML = `
  <div class="page-head"><div><h1>Candidates</h1><p id="cand-count">Search by name, skill, title, company or tag.</p></div>
    <div class="actions">${isStaff() ? `<a class="btn" href="#/upload">Upload CVs</a><button class="btn primary" id="add-cand">Add candidate</button>` : ""}</div></div>
  <div class="card">
    <div class="inline" style="margin-bottom:14px;flex-wrap:wrap">
      <input class="search" id="q" type="search" placeholder="e.g. Python Hyderabad" aria-label="Search candidates">
      <select id="stage" aria-label="Filter by stage"><option value="">All stages</option>${STAGES.map((s) => `<option value="${s}">${STAGE_LABEL[s]}</option>`).join("")}</select>
    </div>
    <div id="cand-list"></div>
    <div style="text-align:center;margin-top:12px"><button class="btn" id="more" hidden>Load more</button></div>
  </div>`;
  async function load(reset) {
    if (reset) { offset = 0; items = []; }
    const params = new URLSearchParams({ q: $("#q").value, stage: $("#stage").value, limit: 50, offset });
    const data = await api("/candidates?" + params);
    items = items.concat(data.items);
    offset = items.length;
    $("#cand-list").innerHTML = candidateTable(items);
    $("#cand-count").textContent = `${data.total} candidate${data.total === 1 ? "" : "s"}`;
    $("#more").hidden = items.length >= data.total;
  }
  $("#q").addEventListener("input", () => { clearTimeout(timer); timer = setTimeout(() => load(true).catch(fail), 300); });
  $("#stage").addEventListener("change", () => load(true).catch(fail));
  $("#more").addEventListener("click", () => load(false).catch(fail));
  $("#add-cand")?.addEventListener("click", () => candidateForm());
  await load(true);
}

function candidateForm(c = null) {
  const v = c || { skills: [], tags: [], consent_status: "not_recorded", source: "Manual" };
  const m = openModal(`${modalHead(c ? "Edit candidate" : "Add candidate")}
  <form id="cand-form">
    <div class="row"><div class="field"><label>Full name</label><input name="full_name" required value="${esc(v.full_name)}"></div>
      <div class="field"><label>Email</label><input name="email" type="email" value="${esc(v.email)}"></div></div>
    <div class="row"><div class="field"><label>Phone</label><input name="phone" value="${esc(v.phone)}"></div>
      <div class="field"><label>Location</label><input name="location" value="${esc(v.location)}"></div></div>
    <div class="row"><div class="field"><label>Current title</label><input name="current_title" value="${esc(v.current_title)}"></div>
      <div class="field"><label>Current company</label><input name="current_company" value="${esc(v.current_company)}"></div></div>
    <div class="row"><div class="field"><label>Years of experience</label><input name="years_experience" type="number" min="0" max="60" step="0.5" value="${esc(v.years_experience)}"></div>
      <div class="field"><label>Source</label><input name="source" value="${esc(v.source)}" list="sources"><datalist id="sources"><option>LinkedIn</option><option>Naukri</option><option>Referral</option><option>Careers Page</option><option>Agency</option><option>Indeed</option></datalist></div></div>
    <div class="field"><label>LinkedIn URL</label><input name="linkedin_url" value="${esc(v.linkedin_url)}"></div>
    <div class="field"><label>Skills <span class="hint">(comma separated)</span></label><input name="skills" value="${esc((v.skills || []).join(", "))}"></div>
    <div class="field"><label>Tags <span class="hint">(comma separated, e.g. "notice 30d, open to relocate")</span></label><input name="tags" value="${esc((v.tags || []).join(", "))}"></div>
    <div class="field"><label>Summary</label><textarea name="summary">${esc(v.summary)}</textarea></div>
    <div class="field"><label>Data consent</label><select name="consent_status">${Object.entries(CONSENT_LABEL).map(([k, l]) => `<option value="${k}" ${k === v.consent_status ? "selected" : ""}>${l}</option>`).join("")}</select></div>
    <div class="modal-foot"><button type="button" class="btn" data-close>Cancel</button><button class="btn primary" type="submit">${c ? "Save changes" : "Add candidate"}</button></div>
  </form>`);
  $("#cand-form", m).addEventListener("submit", (e) => {
    e.preventDefault();
    const d = nullIfEmpty(formData(e.target));
    d.skills = splitList(d.skills); d.tags = splitList(d.tags);
    d.years_experience = d.years_experience === null ? null : Number(d.years_experience);
    if (!d.source) d.source = "Manual";
    withBusy($("button[type=submit]", e.target), async () => {
      const saved = c ? await api(`/candidates/${c.id}`, { method: "PATCH", body: d }) : await api("/candidates", { method: "POST", body: d });
      closeModal(); toast(c ? "Candidate saved" : "Candidate added");
      if (c) route(); else location.hash = `#/candidates/${saved.id}`;
    });
  });
}

function matchPanel(an) {
  if (!an) return "";
  return `<div class="stack" style="margin-top:10px">
    <div class="inline">${scoreBadge(an.score)} <strong>${esc(an.recommendation)}</strong> ${methodBadge(an.method)}</div>
    <p>${esc(an.summary)}</p>
    <div class="notice">${esc(an.notice)}</div>
    <div class="grid cols-2">
      <div><h3>Strengths</h3><ul class="tight">${(an.strengths || []).map((s) => `<li>${esc(s)}</li>`).join("") || "<li>None identified</li>"}</ul></div>
      <div><h3>Gaps</h3><ul class="tight">${(an.gaps || []).map((s) => `<li>${esc(s)}</li>`).join("") || "<li>None identified</li>"}</ul></div>
    </div>
    ${an.evidence?.length ? `<div><h3>Evidence</h3><ul class="tight">${an.evidence.map((s) => `<li>${esc(s)}</li>`).join("")}</ul></div>` : ""}
    ${an.interview_focus?.length ? `<div><h3>Probe in interview</h3><ul class="tight">${an.interview_focus.map((s) => `<li>${esc(s)}</li>`).join("")}</ul></div>` : ""}
    <p class="small muted">Run ${fmtDateTime(an.run_at)} by ${esc(an.run_by)}${an.keyword_score != null ? ` · keyword score ${an.keyword_score}` : ""}</p>
  </div>`;
}

async function pageCandidate(view, id) {
  const c = await api(`/candidates/${id}`);
  view.innerHTML = `
  <div class="page-head"><div><p class="small"><a href="#/candidates">← Candidates</a></p><h1>${esc(c.full_name)}</h1>
    <p>${esc([c.current_title, c.current_company, c.location].filter(Boolean).join(" · ") || "No role details yet")}</p></div>
    <div class="actions">
      ${c.resumes.length ? `<a class="btn" href="/api/candidates/${c.id}/resumes/${c.resumes[0].id}">Download CV</a>` : ""}
      ${isStaff() && c.resumes.length ? `<button class="btn" id="reparse">Re-read CV</button>` : ""}
      ${isStaff() ? `<button class="btn" id="edit">Edit</button><button class="btn primary" id="add-job">Add to job</button>` : ""}
      ${isAdmin() ? `<button class="btn danger" id="delete">Delete</button>` : ""}
    </div></div>
  <div class="grid cols-side">
    <div class="stack">
      <section class="card"><h2>Profile</h2>
        <dl class="kv">
          <dt>Email</dt><dd>${c.email ? `<a href="mailto:${esc(c.email)}">${esc(c.email)}</a>` : "—"}</dd>
          <dt>Phone</dt><dd>${esc(c.phone || "—")}</dd>
          <dt>LinkedIn</dt><dd>${c.linkedin_url ? `<a href="${esc(/^https?:/.test(c.linkedin_url) ? c.linkedin_url : "https://" + c.linkedin_url)}" target="_blank" rel="noopener noreferrer">Profile</a>` : "—"}</dd>
          <dt>Experience</dt><dd>${c.years_experience != null ? esc(c.years_experience) + " years" : "—"}</dd>
          <dt>Source</dt><dd>${esc(c.source)}</dd>
          <dt>Data consent</dt><dd>${esc(CONSENT_LABEL[c.consent_status])}</dd>
          <dt>Profile from</dt><dd>${c.parse_method === "ai" ? methodBadge("ai") : esc(c.parse_method || "manual")}</dd>
          <dt>Added</dt><dd>${fmtDate(c.created_at)}</dd>
        </dl>
        ${c.tags.length ? `<h3 style="margin-top:14px">Tags</h3><div class="chips">${chips(c.tags)}</div>` : ""}
        <h3 style="margin-top:14px">Skills</h3><div class="chips">${chips(c.skills) || '<span class="muted small">None recorded</span>'}</div>
        ${c.summary ? `<h3 style="margin-top:14px">Summary</h3><p>${esc(c.summary)}</p>` : ""}
      </section>
      ${c.experience.length ? `<section class="card"><h2>Experience</h2><ul class="list-plain">${c.experience.map((x) => `<li><strong>${esc(x.title)}</strong> · ${esc(x.company)}<div class="small muted">${esc(x.start || "")} – ${esc(x.end || "")}</div>${(x.highlights || []).length ? `<ul class="tight small">${x.highlights.map((h) => `<li>${esc(h)}</li>`).join("")}</ul>` : ""}</li>`).join("")}</ul></section>` : ""}
      ${c.education.length ? `<section class="card"><h2>Education</h2><ul class="list-plain">${c.education.map((x) => `<li>${esc(x.degree)} · ${esc(x.institution)} <span class="muted">${esc(x.year || "")}</span></li>`).join("")}</ul></section>` : ""}
      ${c.resume_text ? `<section class="card"><details><summary>CV text (${esc(c.resumes[0].filename)})</summary><div class="output resume-text small" style="margin-top:10px">${esc(c.resume_text)}</div></details></section>` : ""}
    </div>
    <div class="stack">
      <section class="card"><h2>Pipelines</h2>
        ${c.applications.length ? c.applications.map((a) => `
          <div class="pcard" data-app="${a.id}">
            <div class="card-head" style="margin:0"><div><a class="name" href="#/jobs/${a.job.id}">${esc(a.job.title)}</a> ${stageBadge(a.stage)}</div>${scoreBadge(a.match_score)}</div>
            ${isStaff() ? `<div class="inline" style="margin-top:8px;flex-wrap:wrap"><select data-stage aria-label="Stage">${stageOptions(a.stage)}</select>
              <button class="btn sm" data-match>${a.match_analysis ? "Re-run match" : "Run match"}</button><button class="btn sm" data-interview>Schedule interview</button></div>` : ""}
            ${a.interviews.length ? `<p class="small muted" style="margin-top:8px">${a.interviews.length} interview(s) · <a href="#/interviews">view</a></p>` : ""}
            ${a.match_analysis ? `<details style="margin-top:8px"><summary>Match analysis</summary>${matchPanel(a.match_analysis)}</details>` : ""}
          </div>`).join("") : empty("Not in any pipeline yet", isStaff() ? " Use “Add to job”." : "")}
      </section>
      <section class="card"><h2>Notes</h2>
        <form id="note-form" class="stack"><textarea name="body" placeholder="Add a note: call summary, notice period, salary expectations…" required></textarea><div><button class="btn primary sm" type="submit">Add note</button></div></form>
        <ul class="list-plain" style="margin-top:10px">${c.notes.map((n) => `<li><div style="white-space:pre-wrap">${esc(n.body)}</div><div class="small muted">${esc(n.author)} · ${fmtDateTime(n.created_at)}</div></li>`).join("")}</ul>
      </section>
    </div>
  </div>`;

  $("#edit")?.addEventListener("click", () => candidateForm(c));
  $("#reparse")?.addEventListener("click", (e) => withBusy(e.target, async () => { await api(`/candidates/${c.id}/reparse`, { method: "POST" }); toast("CV re-read"); route(); }));
  $("#delete")?.addEventListener("click", async () => {
    if (!confirm(`Permanently delete ${c.full_name} and all their files and notes? This can't be undone.`)) return;
    await api(`/candidates/${c.id}`, { method: "DELETE" }).then(() => { toast("Candidate deleted"); location.hash = "#/candidates"; }).catch(fail);
  });
  $("#add-job")?.addEventListener("click", async () => {
    const jobs = (await api("/jobs?status=open")).filter((j) => !c.applications.some((a) => a.job.id === j.id));
    const m = openModal(`${modalHead("Add to a job pipeline")}${jobs.length ? `<form id="aj"><div class="field"><label>Open job</label><select name="job">${jobs.map((j) => `<option value="${j.id}">${esc(j.title)} — ${esc(j.location || "")}</option>`).join("")}</select></div>
      <div class="modal-foot"><button type="button" class="btn" data-close>Cancel</button><button class="btn primary" type="submit">Add</button></div></form>` : empty("No open jobs available", " Create a job first.")}`);
    $("#aj", m)?.addEventListener("submit", (e) => { e.preventDefault(); withBusy($("button[type=submit]", e.target), async () => {
      await api(`/jobs/${e.target.job.value}/applications`, { method: "POST", body: { candidate_id: c.id } }); closeModal(); toast("Added to pipeline"); route(); }); });
  });
  $$("[data-app]").forEach((el) => {
    const appId = el.dataset.app;
    $("[data-stage]", el)?.addEventListener("change", (e) => api(`/applications/${appId}`, { method: "PATCH", body: { stage: e.target.value } }).then(() => { toast("Stage updated"); route(); }).catch(fail));
    $("[data-match]", el)?.addEventListener("click", (e) => withBusy(e.target, async () => { await api(`/applications/${appId}/match`, { method: "POST" }); toast("Match analysis ready"); route(); }));
    $("[data-interview]", el)?.addEventListener("click", () => interviewForm(appId));
  });
  $("#note-form").addEventListener("submit", (e) => { e.preventDefault(); withBusy($("button", e.target), async () => { await api(`/candidates/${c.id}/notes`, { method: "POST", body: formData(e.target) }); route(); }); });
}

function interviewForm(appId) {
  const m = openModal(`${modalHead("Schedule interview")}
  <form id="iv"><div class="row"><div class="field"><label>Date & time</label><input name="scheduled_at" type="datetime-local"></div>
    <div class="field"><label>Format</label><select name="mode"><option value="video">Video</option><option value="onsite">Onsite</option><option value="phone">Phone</option></select></div></div>
    <div class="field"><label>Interviewer</label><input name="interviewer_name" placeholder="Name of interviewer"></div>
    <div class="field"><label>Focus areas <span class="hint">(optional; defaults to gaps from the match analysis)</span></label><input name="focus"></div>
    <p class="small muted">An interview kit with structured questions and a scorecard is created automatically.</p>
    <div class="modal-foot"><button type="button" class="btn" data-close>Cancel</button><button class="btn primary" type="submit">Schedule</button></div></form>`);
  $("#iv", m).addEventListener("submit", (e) => { e.preventDefault(); const d = formData(e.target);
    d.scheduled_at = d.scheduled_at ? new Date(d.scheduled_at).toISOString() : null;
    withBusy($("button[type=submit]", e.target), async () => { await api(`/applications/${appId}/interviews`, { method: "POST", body: d }); closeModal(); toast("Interview scheduled with kit"); route(); }); });
}

// ---------- Upload ----------
async function pageUpload(view) {
  view.innerHTML = `
  <div class="page-head"><div><h1>Upload CVs</h1><p>PDF, DOCX or TXT, up to 25 files at once. Each CV becomes a candidate profile; matching emails update the existing profile.</p></div></div>
  <div class="grid cols-2">
    <section class="card">
      <label class="dropzone" id="drop" for="files"><strong>Drop CV files here</strong><br><span class="muted small">or click to choose files</span></label>
      <input id="files" type="file" multiple accept=".pdf,.docx,.txt" class="sr-only">
      <p id="picked" class="small muted" style="margin-top:10px">No files selected.</p>
      <div class="field"><label for="source">Where are these CVs from?</label><input id="source" value="Upload" list="src2"><datalist id="src2"><option>LinkedIn</option><option>Naukri</option><option>Referral</option><option>Careers Page</option><option>Agency</option></datalist></div>
      <button class="btn primary" id="go" disabled>Upload and read CVs</button>
      <div class="notice">Use only CVs you're permitted to process. Scanned image PDFs can't be read; ask for a text-based file.</div>
    </section>
    <section class="card"><h2>Results</h2><div id="results">${empty("Nothing uploaded yet")}</div></section>
  </div>`;
  let files = [];
  const setFiles = (list) => { files = Array.from(list).slice(0, 25); $("#picked").textContent = files.length ? files.map((f) => f.name).join(", ") : "No files selected."; $("#go").disabled = !files.length; };
  $("#files").addEventListener("change", (e) => setFiles(e.target.files));
  const drop = $("#drop");
  ["dragenter", "dragover"].forEach((ev) => drop.addEventListener(ev, (e) => { e.preventDefault(); drop.classList.add("drag"); }));
  ["dragleave", "drop"].forEach((ev) => drop.addEventListener(ev, (e) => { e.preventDefault(); drop.classList.remove("drag"); }));
  drop.addEventListener("drop", (e) => setFiles(e.dataTransfer.files));
  $("#go").addEventListener("click", (e) => withBusy(e.target, async () => {
    const fd = new FormData();
    files.forEach((f) => fd.append("files", f));
    fd.append("source", $("#source").value || "Upload");
    const { results } = await api("/candidates/upload", { method: "POST", form: fd });
    $("#results").innerHTML = `<table><thead><tr><th>File</th><th>Result</th></tr></thead><tbody>${results.map((r) => `<tr><td class="small">${esc(r.filename)}</td><td>${r.status === "rejected" ? `<span class="badge" style="color:var(--danger)">Not added</span> <span class="small">${esc(r.message)}</span>` : `<a href="#/candidates/${r.candidate_id}">${esc(r.full_name)}</a> <span class="badge open">${r.status === "created" ? "New" : "Updated"}</span> ${methodBadge(r.method)}`}</td></tr>`).join("")}</tbody></table>`;
    const ok = results.filter((r) => r.status !== "rejected").length;
    toast(`${ok} of ${results.length} CVs processed`);
    setFiles([]); $("#files").value = "";
  }));
}

// ---------- Jobs ----------
async function pageJobs(view) {
  const jobs = await api("/jobs");
  view.innerHTML = `
  <div class="page-head"><div><h1>Jobs</h1><p>${jobs.filter((j) => j.status === "open").length} open of ${jobs.length}</p></div>
    <div class="actions">${isStaff() ? `<a class="btn" href="#/tools/jd">Write a JD with AI</a><button class="btn primary" id="new-job">New job</button>` : ""}</div></div>
  <section class="card">${jobs.length ? `<div class="table-wrap"><table><thead><tr><th>Job</th><th>Status</th><th>Must-have skills</th><th>Pipeline</th><th>Hiring manager</th><th>Created</th></tr></thead><tbody>
    ${jobs.map((j) => `<tr><td><a href="#/jobs/${j.id}"><strong>${esc(j.title)}</strong></a><div class="small muted">${esc([j.department, j.location].filter(Boolean).join(" · "))}</div></td>
      <td><span class="badge ${j.status === "open" ? "open" : ""}">${esc(j.status.replace("_", " "))}</span></td><td><div class="chips">${chips(j.must_have_skills, 4)}</div></td>
      <td class="small">${j.total_applications} total${j.stage_counts.interview ? ` · ${j.stage_counts.interview} interviewing` : ""}${j.stage_counts.hired ? ` · ${j.stage_counts.hired} hired` : ""}</td>
      <td class="small">${esc(j.hiring_manager || "—")}</td><td class="small">${fmtDate(j.created_at)}</td></tr>`).join("")}
  </tbody></table></div>` : empty("No jobs yet", " Create your first job opening.")}</section>`;
  $("#new-job")?.addEventListener("click", () => jobForm());
}

async function jobForm(j = null, prefill = {}) {
  const users = await api("/users").catch(() => []);
  const v = j || { status: "open", must_have_skills: [], nice_to_have_skills: [], ...prefill };
  const m = openModal(`${modalHead(j ? "Edit job" : "New job")}
  <form id="job-form">
    <div class="field"><label>Job title</label><input name="title" required value="${esc(v.title)}"></div>
    <div class="row"><div class="field"><label>Department</label><input name="department" value="${esc(v.department)}"></div>
      <div class="field"><label>Location</label><input name="location" value="${esc(v.location)}"></div></div>
    <div class="row"><div class="field"><label>Employment type</label><input name="employment_type" value="${esc(v.employment_type)}" list="etypes"><datalist id="etypes"><option>Full-time</option><option>Contract</option><option>Part-time</option><option>Internship</option></datalist></div>
      <div class="field"><label>Salary range</label><input name="salary_range" value="${esc(v.salary_range)}" placeholder="e.g. 25-35 LPA"></div></div>
    <div class="field"><label>Must-have skills <span class="hint">(comma separated; used for matching)</span></label><input name="must_have_skills" value="${esc((v.must_have_skills || []).join(", "))}"></div>
    <div class="field"><label>Nice-to-have skills</label><input name="nice_to_have_skills" value="${esc((v.nice_to_have_skills || []).join(", "))}"></div>
    <div class="row"><div class="field"><label>Status</label><select name="status">${["open", "on_hold", "closed"].map((s) => `<option value="${s}" ${s === v.status ? "selected" : ""}>${s.replace("_", " ")}</option>`).join("")}</select></div>
      <div class="field"><label>Hiring manager</label><select name="hiring_manager_id"><option value="">None</option>${users.filter((u) => u.is_active).map((u) => `<option value="${u.id}" ${u.id === v.hiring_manager_id ? "selected" : ""}>${esc(u.full_name)}</option>`).join("")}</select></div></div>
    <div class="field"><label>Description</label><textarea name="description" rows="8">${esc(v.description)}</textarea></div>
    <div class="modal-foot"><button type="button" class="btn" data-close>Cancel</button><button class="btn primary" type="submit">${j ? "Save job" : "Create job"}</button></div>
  </form>`, { wide: true });
  $("#job-form", m).addEventListener("submit", (e) => {
    e.preventDefault();
    const d = formData(e.target);
    d.must_have_skills = splitList(d.must_have_skills); d.nice_to_have_skills = splitList(d.nice_to_have_skills);
    d.hiring_manager_id = d.hiring_manager_id ? Number(d.hiring_manager_id) : null;
    ["department", "location", "employment_type", "salary_range"].forEach((k) => { if (!d[k]) d[k] = null; });
    withBusy($("button[type=submit]", e.target), async () => {
      const saved = j ? await api(`/jobs/${j.id}`, { method: "PATCH", body: d }) : await api("/jobs", { method: "POST", body: d });
      closeModal(); toast(j ? "Job saved" : "Job created");
      if (j) route(); else location.hash = `#/jobs/${saved.id}`;
    });
  });
}

async function pageJob(view, id) {
  const j = await api(`/jobs/${id}`);
  const byStage = Object.fromEntries(STAGES.map((s) => [s, []]));
  j.applications.forEach((a) => byStage[a.stage].push(a));
  view.innerHTML = `
  <div class="page-head"><div><p class="small"><a href="#/jobs">← Jobs</a></p><h1>${esc(j.title)}</h1>
    <p>${esc([j.department, j.location, j.employment_type, j.salary_range].filter(Boolean).join(" · "))} · <span class="badge ${j.status === "open" ? "open" : ""}">${esc(j.status.replace("_", " "))}</span></p></div>
    <div class="actions">${isStaff() ? `<button class="btn" id="bool">Generate Boolean</button><button class="btn" id="edit">Edit</button><button class="btn primary" id="suggest">Find matching candidates</button>` : ""}
      ${isAdmin() ? `<button class="btn danger" id="del">Delete</button>` : ""}</div></div>
  <section class="card" style="margin-bottom:16px"><div class="card-head"><h2>Pipeline</h2><span class="small muted">${j.total_applications} candidate(s)</span></div>
    <div class="board">${STAGES.map((s) => `<div class="column"><h3><span>${STAGE_LABEL[s]}</span><span class="muted">${byStage[s].length}</span></h3>
      ${byStage[s].map((a) => `<div class="pcard" data-app="${a.id}"><div class="card-head" style="margin:0"><a class="name" href="#/candidates/${a.candidate.id}">${esc(a.candidate.full_name)}</a>${scoreBadge(a.match_score)}</div>
        <div class="small muted">${esc(a.candidate.current_title || "")}</div>
        ${isStaff() ? `<select data-stage aria-label="Move stage">${stageOptions(a.stage)}</select><button class="btn sm" data-match style="margin-top:6px;width:100%">${a.match_score == null ? "Run match" : "Re-run match"}</button>` : ""}</div>`).join("")}
    </div>`).join("")}</div>
    <p class="small muted" style="margin-top:8px">Match scores are AI or keyword suggestions for review. Moving a candidate is always a recruiter decision.</p>
  </section>
  <div class="grid cols-2">
    <section class="card"><h2>Requirements</h2><h3>Must have</h3><div class="chips">${chips(j.must_have_skills) || '<span class="muted small">None set</span>'}</div>
      <h3 style="margin-top:10px">Nice to have</h3><div class="chips">${chips(j.nice_to_have_skills) || '<span class="muted small">None set</span>'}</div>
      ${j.boolean_string ? `<h3 style="margin-top:14px">Boolean search</h3><div class="output code">${esc(j.boolean_string)}</div><button class="btn sm" id="copy-bool" style="margin-top:6px">Copy</button>` : ""}
      ${j.hiring_manager ? `<p class="small muted" style="margin-top:12px">Hiring manager: ${esc(j.hiring_manager)}</p>` : ""}</section>
    <section class="card"><h2>Description</h2><div class="md">${j.description ? md(j.description) : '<p class="muted">No description yet.</p>'}</div></section>
  </div>`;
  $("#edit")?.addEventListener("click", () => jobForm(j));
  $("#copy-bool")?.addEventListener("click", () => copy(j.boolean_string));
  $("#del")?.addEventListener("click", async () => { if (!confirm(`Delete "${j.title}" and its pipeline? Candidates are kept.`)) return;
    await api(`/jobs/${j.id}`, { method: "DELETE" }).then(() => { toast("Job deleted"); location.hash = "#/jobs"; }).catch(fail); });
  $("#bool")?.addEventListener("click", (e) => withBusy(e.target, async () => {
    const r = await api("/ai/boolean", { method: "POST", body: { title: j.title, must_have: j.must_have_skills, nice_to_have: j.nice_to_have_skills, location: j.location || "" } });
    await api(`/jobs/${j.id}`, { method: "PATCH", body: { boolean_string: r.boolean } });
    toast("Boolean string saved to job"); route();
  }));
  $("#suggest")?.addEventListener("click", async (e) => withBusy(e.target, async () => {
    const s = await api(`/jobs/${j.id}/suggestions`);
    const m = openModal(`${modalHead("Candidates worth a look")}<div class="notice">${esc(s.notice)}</div>
      ${s.items.length ? `<table><thead><tr><th>Candidate</th><th>Score</th><th>Missing</th><th></th></tr></thead><tbody>${s.items.map((x) => `<tr><td><a href="#/candidates/${x.candidate_id}" data-close>${esc(x.full_name)}</a><div class="small muted">${esc(x.current_title || "")}</div></td><td>${scoreBadge(x.score)}</td><td><div class="chips">${chips(x.gaps, 4)}</div></td><td><button class="btn sm" data-add="${x.candidate_id}">Add</button></td></tr>`).join("")}</tbody></table>`
        : empty("No keyword matches", " Try adding must-have skills to the job.")}`, { wide: true });
    $$("[data-add]", m).forEach((b) => b.addEventListener("click", () => withBusy(b, async () => {
      await api(`/jobs/${j.id}/applications`, { method: "POST", body: { candidate_id: Number(b.dataset.add) } });
      b.replaceWith(Object.assign(document.createElement("span"), { className: "badge open", textContent: "Added" }));
      toast("Added to pipeline");
    })));
    $(".overlay").addEventListener("click", (ev) => { if (ev.target.closest("[data-close]") || ev.target.classList.contains("overlay")) route(); });
  }));
  $$("[data-app]").forEach((el) => {
    const appId = el.dataset.app;
    $("[data-stage]", el)?.addEventListener("change", (e) => api(`/applications/${appId}`, { method: "PATCH", body: { stage: e.target.value } }).then(() => { toast("Stage updated"); route(); }).catch(fail));
    $("[data-match]", el)?.addEventListener("click", (e) => withBusy(e.target, async () => {
      const a = await api(`/applications/${appId}/match`, { method: "POST" });
      openModal(`${modalHead(`Match: ${a.candidate.full_name}`)}${matchPanel(a.match_analysis)}<div class="modal-foot"><a class="btn" href="#/candidates/${a.candidate.id}" data-close>Open profile</a><button class="btn primary" data-close>Done</button></div>`, { wide: true });
      $(".overlay").addEventListener("click", (ev) => { if (ev.target.closest("[data-close]")) route(); });
    }));
  });
}

// ---------- Interviews ----------
async function pageInterviews(view) {
  const list = await api("/interviews");
  view.innerHTML = `
  <div class="page-head"><div><h1>Interviews</h1><p>Structured kits and scorecards keep every interview consistent and fair.</p></div></div>
  <section class="card">${list.length ? `<div class="table-wrap"><table><thead><tr><th>When</th><th>Candidate</th><th>Job</th><th>Interviewer</th><th>Status</th><th></th></tr></thead><tbody>
    ${list.map((i) => `<tr><td class="small">${fmtDateTime(i.scheduled_at)}</td><td><a href="#/candidates/${i.candidate.id}">${esc(i.candidate.full_name)}</a></td><td>${esc(i.job.title)}</td>
      <td>${esc(i.interviewer_name || "—")}</td><td><span class="badge ${i.status === "completed" ? "open" : ""}">${esc(i.status)}</span>${i.scorecard ? ` <span class="small muted">scored</span>` : ""}</td>
      <td><button class="btn sm" data-open="${i.id}">Open kit</button></td></tr>`).join("")}</tbody></table></div>`
    : empty("No interviews yet", " Schedule one from a candidate's pipeline card.")}</section>`;
  $$("[data-open]").forEach((b) => b.addEventListener("click", () => interviewModal(list.find((i) => String(i.id) === b.dataset.open))));
}

function interviewModal(i) {
  const kit = i.kit || { questions: [], scorecard_criteria: [] };
  const sc = i.scorecard || { ratings: {} };
  const rate = (name) => `<select name="r_${esc(name)}" aria-label="Rating for ${esc(name)}"><option value="">–</option>${[1, 2, 3, 4, 5].map((n) => `<option ${Number(sc.ratings?.[name]) === n ? "selected" : ""}>${n}</option>`).join("")}</select>`;
  const m = openModal(`${modalHead(`${i.candidate.full_name} · ${i.job.title}`)}
    <p class="small muted">${fmtDateTime(i.scheduled_at)} · ${esc(i.mode)} · ${esc(i.interviewer_name || "Interviewer TBC")} ${methodBadge(kit.method)}</p>
    ${kit.guidance ? `<div class="notice">${esc(kit.guidance)}</div>` : ""}
    <h3>Questions</h3><ol>${kit.questions.map((q) => `<li style="margin-bottom:8px"><strong>${esc(q.question)}</strong><div class="small muted">${esc(q.competency)} · Good answer: ${esc(q.what_good_looks_like)}</div></li>`).join("")}</ol>
    <form id="score"><h3>Scorecard <span class="hint">(1 = weak, 5 = excellent)</span></h3>
      <table><tbody>${kit.scorecard_criteria.map((c) => `<tr><td>${esc(c)}</td><td style="width:90px">${rate(c)}</td></tr>`).join("")}</tbody></table>
      <div class="field" style="margin-top:10px"><label>Overall recommendation</label><select name="recommendation">${["", "strong_yes", "yes", "no", "strong_no"].map((r) => `<option value="${r}" ${sc.recommendation === r ? "selected" : ""}>${r ? r.replace("_", " ") : "Choose…"}</option>`).join("")}</select></div>
      <div class="field"><label>Evidence & notes</label><textarea name="notes">${esc(sc.notes)}</textarea></div>
      ${sc.submitted_by ? `<p class="small muted">Last submitted by ${esc(sc.submitted_by)} · ${fmtDateTime(sc.submitted_at)}</p>` : ""}
      <div class="modal-foot"><button type="button" class="btn" data-close>Close</button><button class="btn primary" type="submit">Submit scorecard</button></div></form>`, { wide: true });
  $("#score", m).addEventListener("submit", (e) => {
    e.preventDefault();
    const d = formData(e.target);
    const ratings = {};
    kit.scorecard_criteria.forEach((c) => { if (d["r_" + c]) ratings[c] = Number(d["r_" + c]); });
    withBusy($("button[type=submit]", e.target), async () => {
      await api(`/interviews/${i.id}`, { method: "PATCH", body: { status: "completed", scorecard: { ratings, recommendation: d.recommendation, notes: d.notes } } });
      closeModal(); toast("Scorecard submitted"); route();
    });
  });
}

// ---------- AI tools ----------
function toolPage(view, { title, intro, form, onSubmit }) {
  view.innerHTML = `<div class="page-head"><div><h1>${esc(title)}</h1><p>${esc(intro)}</p></div></div>
  <div class="grid cols-side"><section class="card"><form id="tool-form">${form}<button class="btn primary" type="submit">Generate</button></form></section>
  <section class="card"><div id="tool-out">${empty("Your result will appear here")}</div></section></div>`;
  $("#tool-form").addEventListener("submit", (e) => { e.preventDefault(); withBusy($("button[type=submit]", e.target), () => onSubmit(formData(e.target), $("#tool-out"))); });
}

async function pageJD(view) {
  toolPage(view, {
    title: "JD generator", intro: "Draft an inclusive, well-structured job description, then turn it into a job in one click.",
    form: `<div class="field"><label>Job title</label><input name="title" required placeholder="e.g. Talent Acquisition Manager"></div>
      <div class="row"><div class="field"><label>Company</label><input name="company"></div><div class="field"><label>Department</label><input name="department"></div></div>
      <div class="row"><div class="field"><label>Location</label><input name="location"></div><div class="field"><label>Seniority</label><select name="seniority"><option>Mid-level</option><option>Senior</option><option>Lead</option><option>Manager</option><option>Director</option><option>Entry-level</option></select></div></div>
      <div class="field"><label>Key skills <span class="hint">(comma separated)</span></label><input name="skills"></div>
      <div class="field"><label>Anything else to include</label><textarea name="notes" placeholder="Team size, reporting line, what makes the role interesting…"></textarea></div>`,
    onSubmit: async (d, out) => {
      d.skills = splitList(d.skills);
      const r = await api("/ai/jd", { method: "POST", body: d });
      out.innerHTML = `<div class="card-head"><h2>Draft</h2>${methodBadge(r.method)}</div><div class="md">${md(r.text)}</div>
        <div class="actions" style="margin-top:12px"><button class="btn" id="cp">Copy</button>${isStaff() ? `<button class="btn primary" id="mk">Create job from this</button>` : ""}</div>`;
      $("#cp").addEventListener("click", () => copy(r.text));
      $("#mk")?.addEventListener("click", () => jobForm(null, { title: d.title, department: d.department, location: d.location, description: r.text, must_have_skills: d.skills }));
    },
  });
}

async function pageBoolean(view) {
  toolPage(view, {
    title: "Boolean search", intro: "Build search strings for LinkedIn Recruiter, Naukri, job boards or Google X-ray.",
    form: `<div class="field"><label>Job title</label><input name="title" required placeholder="e.g. Senior Java Developer"></div>
      <div class="field"><label>Must-have skills</label><input name="must_have" placeholder="Java, Spring Boot"></div>
      <div class="field"><label>Nice-to-have skills</label><input name="nice_to_have" placeholder="AWS, Kafka"></div>
      <div class="field"><label>Exclude</label><input name="exclude" placeholder="intern, trainee"></div>
      <div class="row"><div class="field"><label>Location</label><input name="location"></div><div class="field"><label>Platform</label><select name="platform"><option>LinkedIn</option><option>Naukri</option><option>Indeed</option><option>Google X-ray</option></select></div></div>`,
    onSubmit: async (d, out) => {
      ["must_have", "nice_to_have", "exclude"].forEach((k) => (d[k] = splitList(d[k])));
      const r = await api("/ai/boolean", { method: "POST", body: d });
      out.innerHTML = `<div class="card-head"><h2>Search string</h2>${methodBadge(r.method)}</div><div class="output code">${esc(r.boolean)}</div><button class="btn sm" data-c="-1" style="margin-top:6px">Copy</button>
        ${r.variations.map((v, i) => `<h3 style="margin-top:14px">Variation ${i + 1}</h3><div class="output code">${esc(v)}</div><button class="btn sm" data-c="${i}" style="margin-top:6px">Copy</button>`).join("")}
        ${r.tips.length ? `<h3 style="margin-top:14px">Tips</h3><ul class="tight">${r.tips.map((t) => `<li>${esc(t)}</li>`).join("")}</ul>` : ""}`;
      $$("[data-c]", out).forEach((b) => b.addEventListener("click", () => copy(b.dataset.c === "-1" ? r.boolean : r.variations[Number(b.dataset.c)])));
    },
  });
}

async function pageEmail(view) {
  toolPage(view, {
    title: "Email writer", intro: "Outreach, invitations, offer intros and respectful rejections. Missing facts become [placeholders].",
    form: `<div class="field"><label>Purpose</label><select name="purpose"><option value="outreach">Initial outreach</option><option value="follow_up">Follow-up</option><option value="interview_invite">Interview invitation</option><option value="offer_intro">Offer introduction</option><option value="rejection">Respectful rejection</option></select></div>
      <div class="row"><div class="field"><label>Candidate name</label><input name="candidate_name"></div><div class="field"><label>Role</label><input name="role"></div></div>
      <div class="row"><div class="field"><label>Company</label><input name="company"></div><div class="field"><label>Tone</label><select name="tone"><option>warm and professional</option><option>concise and direct</option><option>formal</option><option>friendly and casual</option></select></div></div>
      <div class="field"><label>Key details</label><textarea name="details" placeholder="e.g. hybrid, 3 days in office; interview on Tuesday 10am via Teams"></textarea></div>`,
    onSubmit: async (d, out) => {
      const r = await api("/ai/email", { method: "POST", body: d });
      out.innerHTML = `<div class="card-head"><h2>Draft email</h2>${methodBadge(r.method)}</div><label>Subject</label><div class="output">${esc(r.subject)}</div>
        <label style="margin-top:10px">Body</label><div class="output">${esc(r.body)}</div>
        <div class="notice">Check names, dates and any figures before sending.</div>
        <div class="actions"><button class="btn" id="cp">Copy</button><a class="btn primary" href="mailto:?subject=${encodeURIComponent(r.subject)}&body=${encodeURIComponent(r.body)}">Open in email app</a></div>`;
      $("#cp").addEventListener("click", () => copy(`Subject: ${r.subject}\n\n${r.body}`));
    },
  });
}

async function pageKit(view) {
  toolPage(view, {
    title: "Interview kit", intro: "Structured, job-related questions with a scorecard, so every candidate is assessed the same way.",
    form: `<div class="field"><label>Role</label><input name="role" required></div>
      <div class="field"><label>Skills to assess</label><input name="skills" placeholder="Stakeholder management, Sourcing"></div>
      <div class="row"><div class="field"><label>Seniority</label><input name="seniority"></div><div class="field"><label>Focus</label><input name="focus" placeholder="e.g. leadership, system design"></div></div>`,
    onSubmit: async (d, out) => {
      d.skills = splitList(d.skills);
      const r = await api("/ai/interview-kit", { method: "POST", body: d });
      out.innerHTML = `<div class="card-head"><h2>Questions</h2>${methodBadge(r.method)}</div>${r.guidance ? `<div class="notice">${esc(r.guidance)}</div>` : ""}
        <ol>${r.questions.map((q) => `<li style="margin-bottom:10px"><strong>${esc(q.question)}</strong><div class="small muted">${esc(q.competency)} · Good answer: ${esc(q.what_good_looks_like)}</div></li>`).join("")}</ol>
        <h3>Scorecard criteria</h3><div class="chips">${chips(r.scorecard_criteria)}</div>`;
    },
  });
}

async function pageChat(view) {
  view.innerHTML = `<div class="page-head"><div><h1>Assistant</h1><p>Ask about sourcing strategy, your pipeline, interview design or drafting. It sees pipeline totals, not personal details.</p></div>
    <div class="actions"><button class="btn" id="clear">New conversation</button></div></div>
  <section class="card chat"><div class="chat-log" id="log"></div>
    <form class="chat-form" id="chat-form"><textarea name="msg" placeholder="e.g. Which open job needs the most sourcing attention?" required aria-label="Message"></textarea><button class="btn primary" type="submit">Send</button></form></section>`;
  const draw = () => {
    $("#log").innerHTML = state.chat.length ? state.chat.map((m) => `<div class="msg ${m.role}">${esc(m.content)}</div>`).join("")
      : empty("Start a conversation", " Try: “Suggest three sourcing channels for senior DevOps engineers in Pune.”");
    $("#log").scrollTop = $("#log").scrollHeight;
  };
  draw();
  $("#clear").addEventListener("click", () => { state.chat = []; draw(); });
  const form = $("#chat-form");
  form.msg.addEventListener("keydown", (e) => { if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); form.requestSubmit(); } });
  form.addEventListener("submit", (e) => {
    e.preventDefault();
    const text = form.msg.value.trim();
    if (!text) return;
    state.chat.push({ role: "user", content: text });
    form.msg.value = ""; draw();
    withBusy($("button", form), async () => {
      const r = await api("/ai/chat", { method: "POST", body: { messages: state.chat.slice(-20) } });
      state.chat.push({ role: "assistant", content: r.reply }); draw();
    });
  });
}

// ---------- Analytics ----------
async function pageAnalytics(view) {
  const a = await api("/analytics/summary");
  const t = a.totals;
  const fMax = Math.max(1, ...a.funnel.map((f) => f.count));
  const wMax = Math.max(1, ...a.applications_per_week.map((w) => w.count));
  const W = 600, H = 150, bw = W / a.applications_per_week.length;
  const svg = `<svg class="chart-svg" viewBox="0 0 ${W} ${H + 20}" role="img" aria-label="Candidates added to pipelines per week">
    ${a.applications_per_week.map((w, i) => { const h = Math.round((w.count / wMax) * H); return `<rect x="${i * bw + 6}" y="${H - h}" width="${bw - 12}" height="${Math.max(h, 1)}" rx="3"><title>${esc(w.week_start)}: ${w.count}</title></rect><text x="${i * bw + bw / 2}" y="${H + 14}" text-anchor="middle">${esc(w.week_start.slice(5))}</text>`; }).join("")}</svg>`;
  view.innerHTML = `
  <div class="page-head"><div><h1>Analytics</h1><p>Pipeline health, conversion and source effectiveness.</p></div></div>
  <div class="stats">${stat(t.candidates, "Candidates")}${stat(t.active_applications, "Active in pipelines")}${stat(t.hires_90d, "Hires, 90 days")}
    ${stat(t.avg_days_to_hire ?? "—", "Avg days to hire")}${stat(t.avg_match_score ?? "—", "Avg match score")}${stat(a.ai_tokens_this_month.toLocaleString(), "AI tokens this month")}</div>
  <div class="grid cols-2">
    <section class="card"><h2>Conversion funnel</h2><p class="small muted">How many pipeline entries ever reached each stage.</p>
      <div class="bars">${a.funnel.map((f, i) => bar(STAGE_LABEL[f.stage], f.count, fMax, i && a.funnel[0].count ? ` (${Math.round((f.count / a.funnel[0].count) * 100)}%)` : "")).join("")}</div></section>
    <section class="card"><h2>Added to pipelines per week</h2>${svg}</section>
    <section class="card"><h2>Sources</h2>${a.sources.length ? `<table><thead><tr><th>Source</th><th>Candidates</th><th>Hires</th><th>Hire rate</th></tr></thead><tbody>
      ${a.sources.map((s) => `<tr><td>${esc(s.source)}</td><td>${s.candidates}</td><td>${s.hires}</td><td>${s.candidates ? Math.round((s.hires / s.candidates) * 100) : 0}%</td></tr>`).join("")}</tbody></table>` : empty("No data yet")}</section>
    <section class="card"><h2>Jobs</h2>${a.jobs.length ? `<table><thead><tr><th>Job</th><th>Status</th><th>Pipeline</th><th>Hired</th><th>Days open</th></tr></thead><tbody>
      ${a.jobs.map((j) => `<tr><td><a href="#/jobs/${j.id}">${esc(j.title)}</a></td><td>${esc(j.status.replace("_", " "))}</td><td>${j.total}</td><td>${j.hired}</td><td>${j.age_days}</td></tr>`).join("")}</tbody></table>` : empty("No jobs yet")}</section>
  </div>`;
}

// ---------- Admin ----------
async function pageUsers(view) {
  const users = await api("/users");
  view.innerHTML = `
  <div class="page-head"><div><h1>Team & roles</h1><p>Admins manage everything. Recruiters work candidates, jobs and AI tools. Hiring managers view and submit scorecards.</p></div>
    <div class="actions"><button class="btn primary" id="add-user">Add team member</button></div></div>
  <section class="card"><div class="table-wrap"><table><thead><tr><th>Name</th><th>Role</th><th>Status</th><th>Last sign-in</th><th></th></tr></thead><tbody>
    ${users.map((u) => `<tr data-user="${u.id}"><td><strong>${esc(u.full_name)}</strong><div class="small muted">${esc(u.email)}</div></td>
      <td><select data-role ${u.id === state.user.id ? "disabled" : ""} aria-label="Role">${Object.entries(ROLE_LABEL).map(([k, l]) => `<option value="${k}" ${k === u.role ? "selected" : ""}>${l}</option>`).join("")}</select></td>
      <td>${u.is_active ? '<span class="badge open">Active</span>' : '<span class="badge">Disabled</span>'}</td><td class="small">${fmtDateTime(u.last_login_at)}</td>
      <td class="actions">${u.id === state.user.id ? "" : `<button class="btn sm" data-toggle>${u.is_active ? "Disable" : "Enable"}</button><button class="btn sm" data-reset>Reset password</button>`}</td></tr>`).join("")}
  </tbody></table></div></section>`;
  const pwHint = "At least 10 characters with upper and lower case letters and a number.";
  $("#add-user").addEventListener("click", () => {
    const m = openModal(`${modalHead("Add team member")}<form id="uf">
      <div class="field"><label>Full name</label><input name="full_name" required></div><div class="field"><label>Work email</label><input name="email" type="email" required></div>
      <div class="field"><label>Role</label><select name="role">${Object.entries(ROLE_LABEL).map(([k, l]) => `<option value="${k}" ${k === "recruiter" ? "selected" : ""}>${l}</option>`).join("")}</select></div>
      <div class="field"><label>Temporary password <span class="hint">(${pwHint})</span></label><input name="password" type="text" required autocomplete="off"></div>
      <p class="small muted">Share the password securely and ask them to change it under their account.</p>
      <div class="modal-foot"><button type="button" class="btn" data-close>Cancel</button><button class="btn primary" type="submit">Add member</button></div></form>`);
    $("#uf", m).addEventListener("submit", (e) => { e.preventDefault(); withBusy($("button[type=submit]", e.target), async () => { await api("/users", { method: "POST", body: formData(e.target) }); closeModal(); toast("Team member added"); route(); }); });
  });
  $$("[data-user]").forEach((row) => {
    const id = row.dataset.user;
    const u = users.find((x) => String(x.id) === id);
    $("[data-role]", row).addEventListener("change", (e) => api(`/users/${id}`, { method: "PATCH", body: { role: e.target.value } }).then(() => toast("Role updated")).catch((err) => { fail(err); route(); }));
    $("[data-toggle]", row)?.addEventListener("click", () => api(`/users/${id}`, { method: "PATCH", body: { is_active: !u.is_active } }).then(() => { toast("Saved"); route(); }).catch(fail));
    $("[data-reset]", row)?.addEventListener("click", () => {
      const m = openModal(`${modalHead(`Reset password for ${u.full_name}`)}<form id="rp"><div class="field"><label>New password <span class="hint">(${pwHint})</span></label><input name="password" type="text" required autocomplete="off"></div>
        <div class="modal-foot"><button type="button" class="btn" data-close>Cancel</button><button class="btn primary" type="submit">Reset</button></div></form>`);
      $("#rp", m).addEventListener("submit", (e) => { e.preventDefault(); withBusy($("button[type=submit]", e.target), async () => { await api(`/users/${id}/reset-password`, { method: "POST", body: formData(e.target) }); closeModal(); toast("Password reset"); }); });
    });
  });
}

async function pageAudit(view) {
  const rows = await api("/audit?limit=300");
  view.innerHTML = `<div class="page-head"><div><h1>Audit log</h1><p>The latest 300 actions: sign-ins, CV uploads and downloads, stage changes, deletions and more.</p></div></div>
  <section class="card"><div class="table-wrap"><table><thead><tr><th>When</th><th>Who</th><th>Action</th><th>Record</th><th>Details</th><th>IP</th></tr></thead><tbody>
  ${rows.map((r) => `<tr><td class="small">${fmtDateTime(r.created_at)}</td><td>${esc(r.user || "—")}</td><td>${esc(r.action.replaceAll("_", " "))}</td>
    <td class="small">${r.entity ? esc(r.entity) + (r.entity_id ? " #" + r.entity_id : "") : "—"}</td><td class="small mono">${r.detail ? esc(JSON.stringify(r.detail)) : ""}</td><td class="small">${esc(r.ip || "")}</td></tr>`).join("")}
  </tbody></table></div></section>`;
}

async function pageAccount(view) {
  const u = state.user;
  const ai = await api("/ai/status");
  view.innerHTML = `<div class="page-head"><div><h1>Your account</h1><p>${esc(u.email)} · ${esc(ROLE_LABEL[u.role])}</p></div></div>
  <div class="grid cols-2">
    <section class="card"><h2>Change password</h2><form id="pw">
      <div class="field"><label>Current password</label><input name="current_password" type="password" required autocomplete="current-password"></div>
      <div class="field"><label>New password <span class="hint">(10+ characters, upper and lower case, a number)</span></label><input name="new_password" type="password" required autocomplete="new-password"></div>
      <button class="btn primary" type="submit">Update password</button></form></section>
    <section class="card"><h2>AI usage</h2><dl class="kv"><dt>Status</dt><dd>${ai.enabled ? "On · " + esc(ai.model) : "Off (rule-based fallbacks in use)"}</dd>
      <dt>Tokens this month</dt><dd>${ai.tokens_used_this_month.toLocaleString()} of ${ai.monthly_budget.toLocaleString()}</dd></dl>
      <div class="bar-track" style="margin-top:12px"><div class="bar-fill" style="width:${Math.min(100, Math.round((ai.tokens_used_this_month / Math.max(1, ai.monthly_budget)) * 100))}%"></div></div>
      <p class="small muted" style="margin-top:8px">When the monthly budget is reached, the app switches to rule-based drafts until the next month.</p></section>
  </div>`;
  $("#pw").addEventListener("submit", (e) => { e.preventDefault(); withBusy($("button", e.target), async () => { await api("/auth/change-password", { method: "POST", body: formData(e.target) }); e.target.reset(); toast("Password updated"); }); });
}

// ---------- Boot ----------
(async function boot() {
  try { state.user = await api("/auth/me"); await startApp(); }
  catch { renderLogin(); }
})();
