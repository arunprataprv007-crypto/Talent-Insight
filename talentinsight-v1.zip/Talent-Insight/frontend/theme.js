// Runs before the page draws, so dark mode doesn't flash white.
(function () {
  var saved = null;
  try { saved = localStorage.getItem("ti-theme"); } catch (e) {}
  var dark = saved ? saved === "dark" : window.matchMedia("(prefers-color-scheme: dark)").matches;
  document.documentElement.setAttribute("data-theme", dark ? "dark" : "light");
})();
