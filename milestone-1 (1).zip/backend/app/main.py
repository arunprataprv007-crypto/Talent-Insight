"""
The starting point of the backend.

Creates the FastAPI app, switches on logging, allows the frontend to call it (CORS),
tags every request with an ID, and catches unexpected errors safely.
"""
import logging
import time
import uuid

from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse

from app.api.routes import health
from app.core.config import settings
from app.core.logging import request_id_ctx, setup_logging

setup_logging(settings.log_level)
logger = logging.getLogger("app")

app = FastAPI(
    title=f"{settings.app_name} API",
    version="0.1.0",
    # The interactive API docs page is handy locally but hidden in production
    docs_url="/docs" if settings.environment != "production" else None,
    redoc_url=None,
)


@app.middleware("http")
async def request_context(request: Request, call_next):
    """Give every request an ID, time it, and log it."""
    request_id = request.headers.get("X-Request-ID") or uuid.uuid4().hex[:12]
    token = request_id_ctx.set(request_id)
    start = time.perf_counter()
    try:
        response = await call_next(request)
    except Exception:
        # Log full details privately; show the user only a safe, generic message
        logger.exception("Unhandled error on %s %s", request.method, request.url.path)
        response = JSONResponse(
            status_code=500,
            content={"detail": "Something went wrong on our side.", "request_id": request_id},
        )
    duration_ms = (time.perf_counter() - start) * 1000
    logger.info(
        "%s %s -> %s (%.0f ms)",
        request.method, request.url.path, response.status_code, duration_ms,
    )
    response.headers["X-Request-ID"] = request_id
    request_id_ctx.reset(token)
    return response


# Only our own frontend may call this API from a browser.
# Added after the middleware above so it wraps everything (including error responses).
app.add_middleware(
    CORSMiddleware,
    allow_origins=[settings.frontend_origin],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(health.router, prefix="/api")


@app.get("/")
def root() -> dict:
    return {"message": f"{settings.app_name} API is running. See /docs for endpoints."}
