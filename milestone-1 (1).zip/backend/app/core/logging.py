"""
Logging setup.

Every log line gets a timestamp, level (INFO/WARNING/ERROR) and a request ID,
so when something breaks you can trace exactly which request caused it.
"""
import logging
import sys
from contextvars import ContextVar

# Holds the ID of the request currently being handled
request_id_ctx: ContextVar[str] = ContextVar("request_id", default="-")


class RequestIdFilter(logging.Filter):
    def filter(self, record: logging.LogRecord) -> bool:
        record.request_id = request_id_ctx.get()
        return True


def setup_logging(level: str = "INFO") -> None:
    handler = logging.StreamHandler(sys.stdout)
    handler.addFilter(RequestIdFilter())
    handler.setFormatter(
        logging.Formatter(
            "%(asctime)s | %(levelname)-7s | req=%(request_id)s | %(name)s | %(message)s"
        )
    )
    root = logging.getLogger()
    root.handlers = [handler]
    root.setLevel(level.upper())
