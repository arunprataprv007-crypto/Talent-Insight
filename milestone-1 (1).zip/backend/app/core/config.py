"""
App settings.

Reads values from the .env file so secrets never live inside the code.
Anywhere in the app, use:  from app.core.config import settings
"""
from functools import lru_cache

from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    app_name: str = "TalentInsight"
    environment: str = "development"
    log_level: str = "INFO"

    database_url: str = (
        "postgresql+psycopg://talentinsight:localdevpassword@localhost:5432/talentinsight"
    )
    frontend_origin: str = "http://localhost:3000"

    # Optional until Milestone 5. Never print or log this value.
    openai_api_key: str = ""

    model_config = SettingsConfigDict(env_file=".env", extra="ignore")


@lru_cache
def get_settings() -> Settings:
    """Load settings once and reuse them (faster than re-reading .env every time)."""
    return Settings()


settings = get_settings()
