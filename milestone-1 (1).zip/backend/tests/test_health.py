"""
Automated tests. Run with:  pytest
Requires the database to be running (docker compose up -d).
"""
from fastapi.testclient import TestClient

from app.main import app

client = TestClient(app)


def test_root_says_running():
    response = client.get("/")
    assert response.status_code == 200
    assert "running" in response.json()["message"]


def test_health_reports_database_ok():
    response = client.get("/api/health")
    assert response.status_code == 200, response.text
    body = response.json()
    assert body["status"] == "ok"
    assert body["database"] == "ok"


def test_every_response_has_request_id():
    response = client.get("/")
    assert "X-Request-ID" in response.headers
