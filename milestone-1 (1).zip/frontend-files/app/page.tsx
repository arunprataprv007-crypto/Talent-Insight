"use client";

/**
 * Temporary home page for Milestone 1.
 * It asks the backend "are you healthy?" and shows the answer.
 * In Milestone 3 this is replaced by the real dashboard.
 */
import { useEffect, useState } from "react";

type Health = {
  status: string;
  app: string;
  environment: string;
  database: string;
};

const API_URL = process.env.NEXT_PUBLIC_API_URL ?? "http://localhost:8000";

function Row({ label, value }: { label: string; value: string }) {
  return (
    <div className="flex justify-between border-b border-slate-200 py-2 dark:border-slate-700">
      <span className="text-slate-500">{label}</span>
      <span className={value === "ok" ? "font-semibold text-emerald-600" : "font-semibold"}>
        {value}
      </span>
    </div>
  );
}

export default function Home() {
  const [health, setHealth] = useState<Health | null>(null);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    fetch(`${API_URL}/api/health`)
      .then(async (res) => setHealth((await res.json()) as Health))
      .catch(() =>
        setError("Can't reach the backend. Check it's running on port 8000 (README, step 5).")
      );
  }, []);

  return (
    <main className="flex min-h-screen items-center justify-center p-6">
      <div className="w-full max-w-md rounded-xl border border-slate-200 p-6 dark:border-slate-700">
        <h1 className="text-xl font-semibold">TalentInsight setup check</h1>
        <p className="mt-1 text-sm text-slate-500">
          Frontend is running. Checking the backend and database now.
        </p>
        <div className="mt-6">
          {error && <p className="text-sm text-red-600">{error}</p>}
          {!error && !health && <p className="text-sm text-slate-500">Checking…</p>}
          {health && (
            <>
              <Row label="Backend" value={health.status} />
              <Row label="Database" value={health.database} />
              <Row label="Environment" value={health.environment} />
            </>
          )}
        </div>
      </div>
    </main>
  );
}
